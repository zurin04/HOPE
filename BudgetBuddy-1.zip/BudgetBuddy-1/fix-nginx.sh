#!/bin/bash

# Quick fix for Nginx port configuration
echo "Fixing Nginx configuration to point to port 5000..."

# Update Nginx configuration
sudo tee /etc/nginx/sites-available/hopempc > /dev/null << 'EOF'
server {
    listen 80;
    server_name _;
    
    client_max_body_size 100M;
    client_body_timeout 120s;
    client_header_timeout 120s;
    
    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        proxy_read_timeout 300s;
        proxy_connect_timeout 75s;
        proxy_send_timeout 300s;
    }
    
    # Security headers
    add_header X-Frame-Options DENY;
    add_header X-Content-Type-Options nosniff;
    add_header X-XSS-Protection "1; mode=block";
    add_header Referrer-Policy "strict-origin-when-cross-origin";
}
EOF

# Test and reload Nginx
if sudo nginx -t; then
    sudo systemctl reload nginx
    echo "✓ Nginx configuration updated and reloaded"
    echo "✓ Now proxying to port 5000"
else
    echo "✗ Nginx configuration test failed"
    exit 1
fi

# Check if application is running on port 5000
if curl -s http://localhost:5000 > /dev/null; then
    echo "✓ Application responding on port 5000"
else
    echo "✗ Application not responding on port 5000"
    echo "Checking PM2 status..."
    pm2 status
fi

echo "Fix completed. Try accessing your IP address again."