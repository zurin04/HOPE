import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { format } from "date-fns";
import { 
  CreditCard, Search, Download, X, RefreshCw, 
  CheckCircle, CalendarDays, ArrowUpDown, FilterIcon
} from "lucide-react";
import AdminLayout from "@/layouts/admin-layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { exportToExcel } from "@/lib/utils/excel";
import { Loan, Payment, User } from "@shared/schema";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { CalendarIcon } from "@radix-ui/react-icons";
import { cn } from "@/lib/utils";
import { Calendar } from "@/components/ui/calendar";
import { Badge } from "@/components/ui/badge";

// Interface for payments with loan and member details
interface PaymentWithDetails extends Payment {
  loanDetails?: Loan;
  memberName?: string;
}

export default function AdminPayments() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState("");
  const [dateFilter, setDateFilter] = useState<Date | undefined>(undefined);
  const [showPaymentDetails, setShowPaymentDetails] = useState(false);
  const [selectedPayment, setSelectedPayment] = useState<PaymentWithDetails | null>(null);
  
  // Fetch loans with payments
  const { data: loansWithPayments, isLoading } = useQuery<{ loan: Loan & { memberName?: string }, payments: Payment[] }[]>({
    queryKey: ["/api/admin/export/loan-payments"],
  });

  // Process the data to get all payments with loan details
  const allPayments: PaymentWithDetails[] = loansWithPayments?.flatMap(loanWithPayments => 
    loanWithPayments.payments.map(payment => ({
      ...payment,
      loanDetails: loanWithPayments.loan,
      memberName: loanWithPayments.loan.memberName
    }))
  ) || [];

  // Filter payments based on search term and date
  const filteredPayments = allPayments.filter(payment => {
    // Filter by search term
    const searchMatches = 
      !searchTerm || 
      payment.id.toString().includes(searchTerm) ||
      payment.loanId.toString().includes(searchTerm) ||
      payment.amount.toString().includes(searchTerm) ||
      (payment.memberName && payment.memberName.toLowerCase().includes(searchTerm.toLowerCase()));
    
    // Filter by date
    const dateMatches = 
      !dateFilter || 
      format(new Date(payment.datePaid), "yyyy-MM-dd") === format(dateFilter, "yyyy-MM-dd");
    
    return searchMatches && dateMatches;
  });

  // Sort payments by date, newest first
  const sortedPayments = [...filteredPayments].sort(
    (a, b) => new Date(b.datePaid).getTime() - new Date(a.datePaid).getTime()
  );

  // Calculate payment metrics
  const totalPayments = allPayments.length;
  const totalAmountPaid = allPayments.reduce((sum, payment) => sum + payment.amount, 0);
  
  // Today's payments
  const today = new Date();
  const todaysPayments = allPayments.filter(payment => 
    format(new Date(payment.datePaid), "yyyy-MM-dd") === format(today, "yyyy-MM-dd")
  );
  const todaysTotal = todaysPayments.reduce((sum, payment) => sum + payment.amount, 0);
  
  // This month's payments
  const thisMonth = today.getMonth();
  const thisYear = today.getFullYear();
  const thisMonthsPayments = allPayments.filter(payment => {
    const paymentDate = new Date(payment.datePaid);
    return paymentDate.getMonth() === thisMonth && paymentDate.getFullYear() === thisYear;
  });
  const thisMonthTotal = thisMonthsPayments.reduce((sum, payment) => sum + payment.amount, 0);

  // View payment details
  const handleViewPaymentDetails = (payment: PaymentWithDetails) => {
    setSelectedPayment(payment);
    setShowPaymentDetails(true);
  };

  // Export payments to Excel
  const handleExport = () => {
    if (!allPayments || allPayments.length === 0) {
      toast({
        title: "Export Failed",
        description: "No payment data available to export.",
        variant: "destructive",
      });
      return;
    }
    
    const formattedPayments = allPayments.map(payment => ({
      id: payment.id,
      loanId: payment.loanId,
      memberName: payment.memberName || `Member ID: ${payment.loanDetails?.userId || 'Unknown'}`,
      amount: payment.amount,
      datePaid: format(new Date(payment.datePaid), "yyyy-MM-dd"),
      loanAmount: payment.loanDetails?.amount || 0,
      loanBalance: payment.loanDetails?.balance || 0,
    }));
    
    const columns = [
      { key: "id", header: "Payment ID" },
      { key: "loanId", header: "Loan ID" },
      { key: "memberName", header: "Member Name" },
      { key: "amount", header: "Payment Amount" },
      { key: "datePaid", header: "Date Paid" },
      { key: "loanAmount", header: "Original Loan Amount" },
      { key: "loanBalance", header: "Current Loan Balance" },
    ];
    
    exportToExcel(formattedPayments, {
      filename: "hopempc-payment-records",
      sheetName: "Payments",
      columns,
    });
    
    toast({
      title: "Export Successful",
      description: `${formattedPayments.length} payments exported to Excel.`,
    });
  };

  return (
    <AdminLayout>
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
        <h1 className="text-2xl font-bold">Payment Records</h1>
        
        <div className="flex mt-4 sm:mt-0 gap-2">
          <Button variant="outline" onClick={handleExport}>
            <Download className="mr-2 h-4 w-4" />
            Export Excel
          </Button>
        </div>
      </div>
      
      {/* Payment Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm text-muted-foreground">Total Payments</p>
                {isLoading ? (
                  <Skeleton className="h-8 w-16 mt-1" />
                ) : (
                  <p className="text-2xl font-bold">{totalPayments}</p>
                )}
              </div>
              <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded-md">
                <CreditCard className="h-5 w-5 text-blue-600 dark:text-blue-400" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm text-muted-foreground">Today's Payments</p>
                {isLoading ? (
                  <Skeleton className="h-8 w-24 mt-1" />
                ) : (
                  <p className="text-2xl font-bold">
                    ₱{todaysTotal.toLocaleString('en-PH', {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2
                    })}
                  </p>
                )}
              </div>
              <div className="p-2 bg-green-100 dark:bg-green-900/30 rounded-md">
                <CalendarDays className="h-5 w-5 text-green-600 dark:text-green-400" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm text-muted-foreground">This Month's Total</p>
                {isLoading ? (
                  <Skeleton className="h-8 w-24 mt-1" />
                ) : (
                  <p className="text-2xl font-bold">
                    ₱{thisMonthTotal.toLocaleString('en-PH', {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2
                    })}
                  </p>
                )}
              </div>
              <div className="p-2 bg-purple-100 dark:bg-purple-900/30 rounded-md">
                <ArrowUpDown className="h-5 w-5 text-purple-600 dark:text-purple-400" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Payment List */}
      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <CardTitle>Payment History</CardTitle>
              <CardDescription>All loan payment records</CardDescription>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-2 w-full md:w-auto">
              <div className="relative w-full sm:w-auto">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  className="pl-8 w-full sm:w-[200px]"
                  placeholder="Search payments..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
                {searchTerm && (
                  <button
                    onClick={() => setSearchTerm("")}
                    className="absolute right-2.5 top-2.5 text-muted-foreground hover:text-foreground"
                  >
                    <X className="h-4 w-4" />
                  </button>
                )}
              </div>
              
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant={"outline"}
                    className={cn(
                      "w-full sm:w-[180px] justify-start text-left font-normal",
                      !dateFilter && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {dateFilter ? format(dateFilter, "PPP") : "Filter by date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={dateFilter}
                    onSelect={setDateFilter}
                    initialFocus
                  />
                  {dateFilter && (
                    <div className="p-3 border-t border-border">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="w-full"
                        onClick={() => setDateFilter(undefined)}
                      >
                        Clear
                      </Button>
                    </div>
                  )}
                </PopoverContent>
              </Popover>
              
              <Button 
                variant="outline" 
                size="icon"
                onClick={() => {
                  queryClient.invalidateQueries({ queryKey: ["/api/admin/export/loan-payments"] });
                }}
                disabled={isLoading}
              >
                <RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4">
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
            </div>
          ) : sortedPayments.length > 0 ? (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Payment ID</TableHead>
                    <TableHead>Loan ID</TableHead>
                    <TableHead>Member</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {sortedPayments.map((payment) => (
                    <TableRow key={payment.id}>
                      <TableCell className="font-medium">#{payment.id}</TableCell>
                      <TableCell>#{payment.loanId}</TableCell>
                      <TableCell>{payment.memberName || `Member ID: ${payment.loanDetails?.userId || 'Unknown'}`}</TableCell>
                      <TableCell>₱{payment.amount.toLocaleString('en-PH', {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                      })}</TableCell>
                      <TableCell>{format(new Date(payment.datePaid), "MMM d, yyyy")}</TableCell>
                      <TableCell>
                        <Badge className="bg-green-500">Completed</Badge>
                      </TableCell>
                      <TableCell>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleViewPaymentDetails(payment)}
                        >
                          Details
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-10">
              <CreditCard className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
              <h3 className="text-lg font-medium mb-1">No Payments Found</h3>
              <p className="text-muted-foreground mb-4">
                {searchTerm || dateFilter
                  ? "No payments match your search criteria."
                  : "There are no payment records available."}
              </p>
              {(searchTerm || dateFilter) && (
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setSearchTerm("");
                    setDateFilter(undefined);
                  }}
                >
                  Clear Filters
                </Button>
              )}
            </div>
          )}
        </CardContent>
      </Card>
      
      {/* Payment Details Dialog */}
      <Dialog open={showPaymentDetails} onOpenChange={setShowPaymentDetails}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Payment Details</DialogTitle>
          </DialogHeader>
          
          {selectedPayment && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Payment ID</p>
                  <p className="font-medium">#{selectedPayment.id}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Status</p>
                  <Badge className="mt-1 bg-green-500">Completed</Badge>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Amount Paid</p>
                  <p className="font-medium">₱{selectedPayment.amount.toLocaleString('en-PH', {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                  })}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Payment Date</p>
                  <p className="font-medium">{format(new Date(selectedPayment.datePaid), "PPP")}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Loan ID</p>
                  <p className="font-medium">#{selectedPayment.loanId}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Member</p>
                  <p className="font-medium">{selectedPayment.memberName || `Member ID: ${selectedPayment.loanDetails?.userId || 'Unknown'}`}</p>
                </div>
              </div>
              
              {selectedPayment.loanDetails && (
                <div className="mt-4 pt-4 border-t">
                  <h3 className="font-medium mb-2">Loan Information</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Original Amount</p>
                      <p className="font-medium">₱{selectedPayment.loanDetails.amount.toLocaleString('en-PH', {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                      })}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Current Balance</p>
                      <p className="font-medium">₱{selectedPayment.loanDetails.balance.toLocaleString('en-PH', {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                      })}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Interest Rate</p>
                      <p className="font-medium">{selectedPayment.loanDetails.interest}%</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Term</p>
                      <p className="font-medium">{selectedPayment.loanDetails.term} months</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Payment Schedule</p>
                      <p className="font-medium capitalize">{selectedPayment.loanDetails.schedule}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Loan Status</p>
                      <Badge className="mt-1" variant={
                        selectedPayment.loanDetails.status === "active" ? "default" :
                        selectedPayment.loanDetails.status === "completed" ? "outline" :
                        "destructive"
                      }>
                        {selectedPayment.loanDetails.status}
                      </Badge>
                    </div>
                  </div>
                </div>
              )}
              
              <div className="mt-6 flex justify-end">
                <Button 
                  variant="outline" 
                  onClick={() => setShowPaymentDetails(false)}
                >
                  Close
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
}
