import { ReactNode, useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useTheme } from "@/components/theme-provider";
import { Button } from "@/components/ui/button";
import { Loader2, Moon, Sun, Menu, Home, User, Coins, HandCoins, CreditCard, Newspaper, LogOut } from "lucide-react";
import { useMobile } from "@/hooks/use-mobile";
import { NotificationMenu } from "@/components/notification-menu";

interface MemberLayoutProps {
  children: ReactNode;
}

export default function MemberLayout({ children }: MemberLayoutProps) {
  const { user, logoutMutation } = useAuth();
  const { theme, setTheme } = useTheme();
  const [location] = useLocation();
  const isMobile = useMobile();
  const [sidebarOpen, setSidebarOpen] = useState(!isMobile);

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  const navItems = [
    { path: "/", label: "Dashboard", icon: <Home className="mr-3 h-5 w-5" /> },
    { path: "/profile", label: "My Profile", icon: <User className="mr-3 h-5 w-5" /> },
    { path: "/capital-shares", label: "Capital Shares", icon: <Coins className="mr-3 h-5 w-5" /> },
    { path: "/loans", label: "Loans", icon: <HandCoins className="mr-3 h-5 w-5" /> },
    { path: "/payments", label: "Payments", icon: <CreditCard className="mr-3 h-5 w-5" /> },
    { path: "/news", label: "Cooperative News", icon: <Newspaper className="mr-3 h-5 w-5" /> },
  ];

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark");
  };

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <div className="flex h-screen bg-gray-100 dark:bg-gray-900">
      {/* Mobile menu button */}
      <div className="fixed bottom-4 right-4 md:hidden z-20">
        <Button 
          onClick={toggleSidebar} 
          size="icon" 
          className="rounded-full bg-primary"
        >
          <Menu className="h-5 w-5" />
        </Button>
      </div>

      {/* Sidebar */}
      <div 
        className={`fixed inset-y-0 left-0 z-10 w-64 bg-sidebar flex flex-col transition-transform duration-300 transform ${
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        } md:translate-x-0`}
      >
        <div className="p-4 border-b border-sidebar-border">
          <h2 className="text-xl font-bold text-sidebar-foreground">HOPEMPC</h2>
          <p className="text-sm text-sidebar-foreground/70">Member Portal</p>
        </div>
        
        <nav className="flex-1 p-4 space-y-2">
          {navItems.map((item) => (
            <Link
              key={item.path}
              href={item.path}
              className={`sidebar-link ${location === item.path ? 'active' : ''}`}
            >
              {item.icon}
              <span>{item.label}</span>
            </Link>
          ))}
        </nav>
        
        <div className="p-4 border-t border-sidebar-border">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium text-sidebar-foreground">{user.name}</p>
              <p className="text-sm text-sidebar-foreground/70">Member ID: #{user.id}</p>
            </div>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={toggleTheme} 
              className="rounded-full text-sidebar-foreground hover:bg-sidebar-primary"
            >
              {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </Button>
          </div>
          <Button 
            onClick={handleLogout} 
            className="mt-4 w-full bg-sidebar-primary hover:bg-sidebar-primary/80 flex items-center justify-center"
            disabled={logoutMutation.isPending}
          >
            {logoutMutation.isPending ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <LogOut className="mr-2 h-4 w-4" />
            )}
            <span>Logout</span>
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 md:ml-64 overflow-auto">
        <div className="p-4 flex justify-end items-center border-b dark:border-gray-800">
          <NotificationMenu />
        </div>
        <div className="p-6">
          {children}
        </div>
      </main>
    </div>
  );
}
