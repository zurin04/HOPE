import { db } from './';
import { sql } from 'drizzle-orm';

/**
 * This script updates the payments table to add verification fields
 */
async function updatePaymentSchema() {
  console.log('Updating payments table schema...');
  
  try {
    // Check if status column exists
    const result = await db.execute(sql`
      SELECT column_name 
      FROM information_schema.columns 
      WHERE table_name = 'payments' AND column_name = 'status'
    `);
    
    if (result.length === 0) {
      // Add status column
      await db.execute(sql`
        ALTER TABLE payments 
        ADD COLUMN status TEXT DEFAULT 'pending' NOT NULL
      `);
      console.log('Added status column to payments table');
      
      // Add verifiedBy column
      await db.execute(sql`
        ALTER TABLE payments 
        ADD COLUMN verified_by INTEGER REFERENCES users(id)
      `);
      console.log('Added verified_by column to payments table');
      
      // Add verifiedAt column
      await db.execute(sql`
        ALTER TABLE payments 
        ADD COLUMN verified_at TIMESTAMP
      `);
      console.log('Added verified_at column to payments table');
      
      // Add paymentMethod column
      await db.execute(sql`
        ALTER TABLE payments 
        ADD COLUMN payment_method TEXT DEFAULT 'counter' NOT NULL
      `);
      console.log('Added payment_method column to payments table');
      
      // Add paymentNote column
      await db.execute(sql`
        ALTER TABLE payments 
        ADD COLUMN payment_note TEXT
      `);
      console.log('Added payment_note column to payments table');
    } else {
      console.log('Payment verification fields already exist');
    }
    
    // Check if member_savings table exists
    const savingsTableResult = await db.execute(sql`
      SELECT tablename 
      FROM pg_tables 
      WHERE tablename = 'member_savings'
    `);
    
    if (savingsTableResult.length === 0) {
      // Create member_savings table
      await db.execute(sql`
        CREATE TABLE member_savings (
          id SERIAL PRIMARY KEY,
          user_id INTEGER NOT NULL REFERENCES users(id),
          amount DOUBLE PRECISION NOT NULL,
          balance DOUBLE PRECISION NOT NULL,
          transaction_type TEXT NOT NULL,
          date TIMESTAMP DEFAULT NOW() NOT NULL,
          note TEXT,
          processed_by INTEGER REFERENCES users(id)
        )
      `);
      console.log('Created member_savings table');
    } else {
      console.log('Member savings table already exists');
    }
    
    // Check if dividend_records table exists
    const dividendTableResult = await db.execute(sql`
      SELECT tablename 
      FROM pg_tables 
      WHERE tablename = 'dividend_records'
    `);
    
    if (dividendTableResult.length === 0) {
      // Create dividend_records table
      await db.execute(sql`
        CREATE TABLE dividend_records (
          id SERIAL PRIMARY KEY,
          year INTEGER NOT NULL,
          total_amount DOUBLE PRECISION NOT NULL,
          distribution_date TIMESTAMP DEFAULT NOW() NOT NULL,
          note TEXT,
          status TEXT DEFAULT 'pending' NOT NULL
        )
      `);
      console.log('Created dividend_records table');
    } else {
      console.log('Dividend records table already exists');
    }
    
    console.log('Schema update completed successfully!');
  } catch (error) {
    console.error('Error updating schema:', error);
  }
}

updatePaymentSchema();
