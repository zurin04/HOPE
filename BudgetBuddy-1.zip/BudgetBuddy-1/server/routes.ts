import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { hashPassword } from "./auth";
import { insertLoanSchema, insertPaymentSchema, insertCapitalShareSchema, 
         insertOfficerSchema, insertNewsFeedSchema, insertMonthlyIncomeSchema,
         insertMonthlyExpensesSchema, insertNotificationSchema } from "@shared/schema";
import { z } from "zod";
import { format } from 'date-fns';

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication routes
  setupAuth(app);

  // Member routes
  app.get("/api/members/profile", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      const user = req.user;
      const capitalShare = await storage.getCapitalShare(user.id);
      
      res.json({
        user,
        capitalShare
      });
    } catch (error) {
      console.error("Error fetching profile:", error);
      res.status(500).json({ message: "Error fetching profile" });
    }
  });

  app.get("/api/members/capital-shares", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      const capitalShare = await storage.getCapitalShare(req.user.id);
      res.json(capitalShare);
    } catch (error) {
      console.error("Error fetching capital shares:", error);
      res.status(500).json({ message: "Error fetching capital shares" });
    }
  });

  app.get("/api/members/loans", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      const loans = await storage.getLoansByUser(req.user.id);
      res.json(loans);
    } catch (error) {
      console.error("Error fetching loans:", error);
      res.status(500).json({ message: "Error fetching loans" });
    }
  });
  
  app.post("/api/members/loans", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      // Check if user has enough capital share to borrow against
      const capitalShare = await storage.getCapitalShare(req.user.id);
      if (!capitalShare) {
        return res.status(400).json({ message: "You do not have any capital shares to borrow against" });
      }
      
      // User can borrow up to 80% of their capital share
      const maxLoanAmount = capitalShare.amount * 0.8;
      
      const loanData = {
        ...req.body,
        userId: req.user.id,
        balance: req.body.amount,
        status: "pending", // Set to pending for approval workflow
        approvalStatus: "pending", // Initial approval status
        startDate: new Date().toISOString().split('T')[0], // Format as YYYY-MM-DD
      };
      
      // Validate loan amount against capital share
      if (loanData.amount > maxLoanAmount) {
        return res.status(400).json({ 
          message: `Loan amount exceeds the maximum allowed (80% of your capital share: ${maxLoanAmount.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })})` 
        });
      }
      
      // Validate loan data with schema
      const parsedLoanData = insertLoanSchema.parse(loanData);
      
      // Create the loan with pending status
      const loan = await storage.createLoan(parsedLoanData);
      
      // Create notification for admin
      await storage.createNotification({
        userId: 1, // Admin user ID
        title: "New Loan Application",
        message: `Member ${req.user.name} has applied for a loan of ₱${loan.amount.toLocaleString('en-PH', { minimumFractionDigits: 2 })}.`,
        type: "loan_request",
        relatedId: loan.id
      });
      
      res.status(201).json(loan);
    } catch (error) {
      console.error("Error creating loan:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid loan data", errors: error.errors });
      }
      res.status(500).json({ message: "Error creating loan" });
    }
  });

  app.get("/api/members/loans/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      const loanId = parseInt(req.params.id);
      const loan = await storage.getLoan(loanId);
      
      if (!loan) {
        return res.status(404).json({ message: "Loan not found" });
      }
      
      if (loan.userId !== req.user.id) {
        return res.status(403).json({ message: "Not authorized to view this loan" });
      }
      
      const payments = await storage.getPaymentsByLoan(loanId);
      
      res.json({
        loan,
        payments
      });
    } catch (error) {
      console.error("Error fetching loan details:", error);
      res.status(500).json({ message: "Error fetching loan details" });
    }
  });

  app.post("/api/members/loans/:id/payments", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      const loanId = parseInt(req.params.id);
      const loan = await storage.getLoan(loanId);
      
      if (!loan) {
        return res.status(404).json({ message: "Loan not found" });
      }
      
      if (loan.userId !== req.user.id) {
        return res.status(403).json({ message: "Not authorized to pay this loan" });
      }
      
      const validatedData = insertPaymentSchema.parse({ ...req.body, loanId });
      const payment = await storage.createPayment(validatedData);
      
      // Update loan balance
      const newBalance = loan.balance - validatedData.amount;
      const loanStatus = newBalance <= 0 ? "completed" : "active";
      
      await storage.updateLoan(loanId, {
        balance: Math.max(0, newBalance),
        status: loanStatus
      });
      
      res.status(201).json(payment);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error creating payment:", error);
      res.status(500).json({ message: "Error creating payment" });
    }
  });

  app.get("/api/members/payments", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      const loans = await storage.getLoansByUser(req.user.id);
      const paymentsPromises = loans.map(loan => storage.getPaymentsByLoan(loan.id));
      const paymentsArrays = await Promise.all(paymentsPromises);
      
      // Flatten the array of payment arrays
      const payments = paymentsArrays.flat();
      
      res.json(payments);
    } catch (error) {
      console.error("Error fetching payments:", error);
      res.status(500).json({ message: "Error fetching payments" });
    }
  });

  app.get("/api/news", async (req, res) => {
    try {
      const news = await storage.getAllNews();
      res.json(news);
    } catch (error) {
      console.error("Error fetching news:", error);
      res.status(500).json({ message: "Error fetching news" });
    }
  });
  
  // Payment verification endpoints
  app.get("/api/admin/payments/pending", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.sendStatus(403);
    }
    
    try {
      const pendingPayments = await storage.getPendingPayments();
      const paymentsWithDetails = await Promise.all(
        pendingPayments.map(async (payment) => {
          const loan = await storage.getLoan(payment.loanId);
          const member = loan ? await storage.getUser(loan.userId) : null;
          
          return {
            ...payment,
            loan,
            memberName: member?.name
          };
        })
      );
      
      res.json(paymentsWithDetails);
    } catch (error) {
      console.error("Error fetching pending payments:", error);
      res.status(500).json({ message: "Error fetching pending payments" });
    }
  });
  
  app.post("/api/admin/payments/:paymentId/verify", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.sendStatus(403);
    }
    
    const paymentId = parseInt(req.params.paymentId);
    const { paymentNote } = req.body;
    
    try {
      const payment = await storage.getPayment(paymentId);
      if (!payment) {
        return res.status(404).json({ message: "Payment not found" });
      }
      
      if (payment.status === 'verified') {
        return res.status(400).json({ message: "Payment is already verified" });
      }
      
      const verifiedPayment = await storage.verifyPayment(
        paymentId, 
        req.user.id, 
        paymentNote
      );
      
      // Get the loan and borrower information
      const loan = await storage.getLoan(payment.loanId);
      if (loan) {
        // Notify the borrower that their payment has been verified
        await storage.createNotification({
          userId: loan.userId,
          title: "Payment Verified",
          message: `Your payment of ₱${payment.amount.toFixed(2)} has been verified.`,
          type: "payment_verified",
          relatedId: payment.id
        });
      }
      
      res.json(verifiedPayment);
    } catch (error) {
      console.error("Error verifying payment:", error);
      res.status(500).json({ message: "Error verifying payment" });
    }
  });
  
  // Member Savings endpoints
  app.get("/api/member/savings", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }
    
    try {
      const savings = await storage.getMemberSavings(req.user.id);
      res.json(savings);
    } catch (error) {
      console.error("Error fetching member savings:", error);
      res.status(500).json({ message: "Error fetching member savings" });
    }
  });
  
  app.get("/api/member/savings/balance", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }
    
    try {
      const balance = await storage.getMemberSavingsBalance(req.user.id);
      res.json({ balance });
    } catch (error) {
      console.error("Error fetching savings balance:", error);
      res.status(500).json({ message: "Error fetching savings balance" });
    }
  });
  
  app.post("/api/admin/savings/transaction", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.sendStatus(403);
    }
    
    try {
      const { userId, amount, transactionType, note } = req.body;
      
      if (!userId || !amount || !transactionType) {
        return res.status(400).json({ message: "Missing required fields" });
      }
      
      if (transactionType !== 'deposit' && transactionType !== 'withdrawal' && transactionType !== 'dividend') {
        return res.status(400).json({ message: "Invalid transaction type" });
      }
      
      const transaction = await storage.createSavingsTransaction({
        userId,
        amount: parseFloat(amount),
        transactionType,
        note,
        processedBy: req.user.id
      });
      
      // Create notification for the member
      const message = transactionType === 'deposit' 
        ? `₱${amount} has been deposited to your savings account.`
        : transactionType === 'withdrawal'
        ? `₱${amount} has been withdrawn from your savings account.`
        : `₱${amount} dividend has been added to your savings account.`;
      
      await storage.createNotification({
        userId,
        title: `Savings ${transactionType.charAt(0).toUpperCase() + transactionType.slice(1)}`,
        message,
        type: `savings_${transactionType}`,
        relatedId: transaction.id
      });
      
      res.status(201).json(transaction);
    } catch (error: any) {
      console.error("Error creating savings transaction:", error);
      res.status(500).json({ 
        message: error.message || "Error creating savings transaction" 
      });
    }
  });
  
  // Dividend endpoints
  app.get("/api/admin/dividends", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.sendStatus(403);
    }
    
    try {
      const dividends = await storage.getDividendRecords();
      res.json(dividends);
    } catch (error) {
      console.error("Error fetching dividends:", error);
      res.status(500).json({ message: "Error fetching dividends" });
    }
  });
  
  app.post("/api/admin/dividends", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.sendStatus(403);
    }
    
    try {
      const { year, totalAmount, note } = req.body;
      
      if (!year || !totalAmount) {
        return res.status(400).json({ message: "Missing required fields" });
      }
      
      const dividend = await storage.createDividendRecord({
        year: parseInt(year),
        totalAmount: parseFloat(totalAmount),
        note,
        status: 'pending'
      });
      
      res.status(201).json(dividend);
    } catch (error) {
      console.error("Error creating dividend record:", error);
      res.status(500).json({ message: "Error creating dividend record" });
    }
  });
  
  app.post("/api/admin/dividends/:id/distribute", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.sendStatus(403);
    }
    
    try {
      const dividendId = parseInt(req.params.id);
      const success = await storage.distributeDividends(dividendId, req.user.id);
      
      if (!success) {
        return res.status(400).json({ message: "Unable to distribute dividends" });
      }
      
      res.json({ success: true });
    } catch (error) {
      console.error("Error distributing dividends:", error);
      res.status(500).json({ message: "Error distributing dividends" });
    }
  });
  
  // Notification endpoints
  app.get("/api/notifications", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      const notifications = await storage.getNotificationsForUser(req.user.id);
      res.json(notifications);
    } catch (error) {
      console.error("Error fetching notifications:", error);
      res.status(500).json({ message: "Error fetching notifications" });
    }
  });
  
  app.get("/api/notifications/unread", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      const notifications = await storage.getUnreadNotificationsForUser(req.user.id);
      res.json(notifications);
    } catch (error) {
      console.error("Error fetching unread notifications:", error);
      res.status(500).json({ message: "Error fetching unread notifications" });
    }
  });
  
  app.post("/api/notifications/:id/read", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      const notificationId = parseInt(req.params.id);
      const success = await storage.markNotificationAsRead(notificationId);
      
      if (!success) {
        return res.status(404).json({ message: "Notification not found" });
      }
      
      res.sendStatus(200);
    } catch (error) {
      console.error("Error marking notification as read:", error);
      res.status(500).json({ message: "Error marking notification as read" });
    }
  });
  
  app.post("/api/notifications/read-all", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      await storage.markAllNotificationsAsRead(req.user.id);
      res.sendStatus(200);
    } catch (error) {
      console.error("Error marking all notifications as read:", error);
      res.status(500).json({ message: "Error marking all notifications as read" });
    }
  });

  // Admin routes
  app.get("/api/admin/members", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.sendStatus(403);
    }
    
    try {
      const members = await storage.getAllMembers();
      res.json(members);
    } catch (error) {
      console.error("Error fetching members:", error);
      res.status(500).json({ message: "Error fetching members" });
    }
  });

  app.get("/api/admin/members/active", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.sendStatus(403);
    }
    
    try {
      const members = await storage.getActiveMembers();
      res.json(members);
    } catch (error) {
      console.error("Error fetching active members:", error);
      res.status(500).json({ message: "Error fetching active members" });
    }
  });

  app.get("/api/admin/members/inactive", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.sendStatus(403);
    }
    
    try {
      const members = await storage.getInactiveMembers();
      res.json(members);
    } catch (error) {
      console.error("Error fetching inactive members:", error);
      res.status(500).json({ message: "Error fetching inactive members" });
    }
  });

  app.get("/api/admin/members/:id", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.sendStatus(403);
    }
    
    try {
      const memberId = parseInt(req.params.id);
      const member = await storage.getUser(memberId);
      
      if (!member) {
        return res.status(404).json({ message: "Member not found" });
      }
      
      const capitalShare = await storage.getCapitalShare(memberId);
      const loans = await storage.getLoansByUser(memberId);
      
      res.json({
        member,
        capitalShare,
        loans
      });
    } catch (error) {
      console.error("Error fetching member details:", error);
      res.status(500).json({ message: "Error fetching member details" });
    }
  });

  app.put("/api/admin/members/:id", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.sendStatus(403);
    }
    
    try {
      const memberId = parseInt(req.params.id);
      const member = await storage.getUser(memberId);
      
      if (!member) {
        return res.status(404).json({ message: "Member not found" });
      }
      
      const updatedMember = await storage.updateUser(memberId, req.body);
      res.json(updatedMember);
    } catch (error) {
      console.error("Error updating member:", error);
      res.status(500).json({ message: "Error updating member" });
    }
  });

  app.delete("/api/admin/members/:id", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.sendStatus(403);
    }
    
    try {
      const memberId = parseInt(req.params.id);
      const member = await storage.getUser(memberId);
      
      if (!member) {
        return res.status(404).json({ message: "Member not found" });
      }
      
      // Don't allow deleting your own account
      if (memberId === req.user.id) {
        return res.status(400).json({ message: "You cannot delete your own account" });
      }
      
      // Attempt deletion
      await storage.deleteUser(memberId);
      res.sendStatus(200);
    } catch (error) {
      console.error("Error deleting member:", error);
      const errorMessage = error instanceof Error ? error.message : "Error deleting member";
      res.status(500).json({ message: errorMessage });
    }
  });

  app.put("/api/admin/capital-shares/:id", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.sendStatus(403);
    }
    
    try {
      const capitalShareId = parseInt(req.params.id);
      const validatedData = insertCapitalShareSchema.parse(req.body);
      
      const updatedCapitalShare = await storage.updateCapitalShare(capitalShareId, validatedData.amount);
      
      if (!updatedCapitalShare) {
        return res.status(404).json({ message: "Capital share not found" });
      }
      
      res.json(updatedCapitalShare);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error updating capital share:", error);
      res.status(500).json({ message: "Error updating capital share" });
    }
  });

  app.post("/api/admin/loans", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.sendStatus(403);
    }
    
    try {
      const validatedData = insertLoanSchema.parse(req.body);
      const loan = await storage.createLoan(validatedData);
      res.status(201).json(loan);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error creating loan:", error);
      res.status(500).json({ message: "Error creating loan" });
    }
  });

  app.get("/api/admin/loans", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.sendStatus(403);
    }
    
    try {
      const loans = await storage.getAllLoans();
      res.json(loans);
    } catch (error) {
      console.error("Error fetching loans:", error);
      res.status(500).json({ message: "Error fetching loans" });
    }
  });

  app.get("/api/admin/loans/:id", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.sendStatus(403);
    }
    
    try {
      const loanId = parseInt(req.params.id);
      const loan = await storage.getLoan(loanId);
      
      if (!loan) {
        return res.status(404).json({ message: "Loan not found" });
      }
      
      const payments = await storage.getPaymentsByLoan(loanId);
      const member = await storage.getUser(loan.userId);
      
      res.json({
        loan,
        payments,
        member
      });
    } catch (error) {
      console.error("Error fetching loan details:", error);
      res.status(500).json({ message: "Error fetching loan details" });
    }
  });

  app.post("/api/admin/loans/:id/payments", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.sendStatus(403);
    }
    
    try {
      const loanId = parseInt(req.params.id);
      const loan = await storage.getLoan(loanId);
      
      if (!loan) {
        return res.status(404).json({ message: "Loan not found" });
      }
      
      const validatedData = insertPaymentSchema.parse({ ...req.body, loanId });
      const payment = await storage.createPayment(validatedData);
      
      // Update loan balance
      const newBalance = loan.balance - validatedData.amount;
      const loanStatus = newBalance <= 0 ? "completed" : "active";
      
      await storage.updateLoan(loanId, {
        balance: Math.max(0, newBalance),
        status: loanStatus
      });
      
      // Create notification for user about the payment
      await storage.createNotification({
        userId: loan.userId,
        title: "Payment Received",
        message: `Your payment of ₱${validatedData.amount.toLocaleString('en-PH', { minimumFractionDigits: 2 })} has been recorded for your loan and is pending verification. Remaining balance: ₱${Math.max(0, newBalance).toLocaleString('en-PH', { minimumFractionDigits: 2 })}.`,
        type: "payment_confirmation",
        relatedId: loanId
      });
      
      res.status(201).json(payment);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error creating payment:", error);
      res.status(500).json({ message: "Error creating payment" });
    }
  });
  
  // New endpoint for loan approval/rejection
  app.post("/api/admin/loans/:id/approve", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.sendStatus(403);
    }
    
    try {
      const loanId = parseInt(req.params.id);
      const { action, note } = req.body;
      
      // Validate action
      if (action !== "approve" && action !== "reject") {
        return res.status(400).json({ message: "Invalid action. Must be 'approve' or 'reject'" });
      }
      
      const loan = await storage.getLoan(loanId);
      
      if (!loan) {
        return res.status(404).json({ message: "Loan not found" });
      }
      
      // Update loan status
      const approvalStatus = action === "approve" ? "approved" : "rejected";
      const status = action === "approve" ? "active" : "rejected";
      
      const updatedLoan = await storage.updateLoan(loanId, {
        approvalStatus,
        status,
        approvedBy: req.user.id,
        approvedAt: new Date(),
        approvalNote: note || null
      });
      
      // Notify user about the decision
      const notificationType = action === "approve" ? "loan_approved" : "loan_rejected";
      const notificationTitle = action === "approve" ? "Loan Approved" : "Loan Rejected";
      const notificationMessage = action === "approve" 
        ? `Your loan application for ₱${loan.amount.toLocaleString('en-PH', { minimumFractionDigits: 2 })} has been approved. ${note ? `Note: ${note}` : ''}` 
        : `Your loan application for ₱${loan.amount.toLocaleString('en-PH', { minimumFractionDigits: 2 })} has been rejected. ${note ? `Reason: ${note}` : 'Please contact the admin for more information.'}`;      
      
      await storage.createNotification({
        userId: loan.userId,
        title: notificationTitle,
        message: notificationMessage,
        type: notificationType,
        relatedId: loanId
      });
      
      res.json(updatedLoan);
    } catch (error) {
      console.error("Error processing loan approval:", error);
      res.status(500).json({ message: "Error processing loan approval" });
    }
  });

  app.get("/api/admin/funds", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.sendStatus(403);
    }
    
    try {
      const funds = await storage.getFunds();
      res.json(funds || { onhandCash: 0, capitalFund: 0, reserveFund: 0 });
    } catch (error) {
      console.error("Error fetching funds:", error);
      res.status(500).json({ message: "Error fetching funds" });
    }
  });

  app.put("/api/admin/funds", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.sendStatus(403);
    }
    
    try {
      const updatedFunds = await storage.updateFunds(req.body);
      res.json(updatedFunds);
    } catch (error) {
      console.error("Error updating funds:", error);
      res.status(500).json({ message: "Error updating funds" });
    }
  });

  app.get("/api/admin/officers", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.sendStatus(403);
    }
    
    try {
      const officers = await storage.getOfficers();
      const officersWithDetails = await Promise.all(
        officers.map(async (officer) => {
          const user = await storage.getUser(officer.userId);
          return {
            ...officer,
            name: user?.name
          };
        })
      );
      
      res.json(officersWithDetails);
    } catch (error) {
      console.error("Error fetching officers:", error);
      res.status(500).json({ message: "Error fetching officers" });
    }
  });

  // Endpoint for checking if current user is an officer (accessible to all authenticated users)
  app.get("/api/user/officer-status", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }
    
    try {
      const officers = await storage.getOfficers();
      const isOfficer = req.user.role === 'admin' || officers.some(officer => officer.userId === req.user.id);
      
      res.json({ 
        isOfficer,
        role: req.user.role,
        userId: req.user.id 
      });
    } catch (error) {
      console.error("Error checking officer status:", error);
      res.status(500).json({ message: "Error checking officer status" });
    }
  });

  app.post("/api/admin/officers", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.sendStatus(403);
    }
    
    try {
      const validatedData = insertOfficerSchema.parse(req.body);
      const officer = await storage.assignOfficer(validatedData);
      res.status(201).json(officer);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error assigning officer:", error);
      res.status(500).json({ message: "Error assigning officer" });
    }
  });

  app.delete("/api/admin/officers/:id", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.sendStatus(403);
    }
    
    try {
      const officerId = parseInt(req.params.id);
      const success = await storage.removeOfficer(officerId);
      
      if (!success) {
        return res.status(404).json({ message: "Officer not found" });
      }
      
      res.sendStatus(200);
    } catch (error) {
      console.error("Error removing officer:", error);
      res.status(500).json({ message: "Error removing officer" });
    }
  });

  app.get("/api/admin/income", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.sendStatus(403);
    }
    
    try {
      const year = parseInt(req.query.year as string) || new Date().getFullYear();
      const month = parseInt(req.query.month as string) || new Date().getMonth() + 1;
      
      const incomes = await storage.getMonthlyIncomeByDate(year, month);
      res.json(incomes);
    } catch (error) {
      console.error("Error fetching income:", error);
      res.status(500).json({ message: "Error fetching income" });
    }
  });

  app.post("/api/admin/income", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.sendStatus(403);
    }
    
    try {
      const validatedData = insertMonthlyIncomeSchema.parse(req.body);
      const income = await storage.createMonthlyIncome(validatedData);
      res.status(201).json(income);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error creating income:", error);
      res.status(500).json({ message: "Error creating income" });
    }
  });

  app.get("/api/admin/expenses", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.sendStatus(403);
    }
    
    try {
      const year = parseInt(req.query.year as string) || new Date().getFullYear();
      const month = parseInt(req.query.month as string) || new Date().getMonth() + 1;
      
      const expenses = await storage.getMonthlyExpensesByDate(year, month);
      res.json(expenses);
    } catch (error) {
      console.error("Error fetching expenses:", error);
      res.status(500).json({ message: "Error fetching expenses" });
    }
  });

  app.post("/api/admin/expenses", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.sendStatus(403);
    }
    
    try {
      const validatedData = insertMonthlyExpensesSchema.parse(req.body);
      const expense = await storage.createMonthlyExpense(validatedData);
      res.status(201).json(expense);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error creating expense:", error);
      res.status(500).json({ message: "Error creating expense" });
    }
  });

  app.get("/api/admin/news", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.sendStatus(403);
    }
    
    try {
      const news = await storage.getAllNews();
      res.json(news);
    } catch (error) {
      console.error("Error fetching news:", error);
      res.status(500).json({ message: "Error fetching news" });
    }
  });

  app.post("/api/admin/news", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.sendStatus(403);
    }
    
    try {
      const validatedData = insertNewsFeedSchema.parse({
        ...req.body,
        createdBy: req.user.id
      });
      
      const news = await storage.createNews(validatedData);
      res.status(201).json(news);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error creating news:", error);
      res.status(500).json({ message: "Error creating news" });
    }
  });

  app.put("/api/admin/news/:id", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.sendStatus(403);
    }
    
    try {
      const newsId = parseInt(req.params.id);
      const news = await storage.updateNews(newsId, req.body);
      
      if (!news) {
        return res.status(404).json({ message: "News not found" });
      }
      
      res.json(news);
    } catch (error) {
      console.error("Error updating news:", error);
      res.status(500).json({ message: "Error updating news" });
    }
  });

  app.delete("/api/admin/news/:id", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.sendStatus(403);
    }
    
    try {
      const newsId = parseInt(req.params.id);
      const success = await storage.deleteNews(newsId);
      
      if (!success) {
        return res.status(404).json({ message: "News not found" });
      }
      
      res.sendStatus(200);
    } catch (error) {
      console.error("Error deleting news:", error);
      res.status(500).json({ message: "Error deleting news" });
    }
  });

  // Excel export routes
  app.get("/api/admin/export/active-members", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.sendStatus(403);
    }
    
    try {
      const members = await storage.getActiveMembers();
      // Client will handle the excel generation
      res.json(members);
    } catch (error) {
      console.error("Error exporting active members:", error);
      res.status(500).json({ message: "Error exporting active members" });
    }
  });

  app.get("/api/admin/export/inactive-members", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.sendStatus(403);
    }
    
    try {
      const members = await storage.getInactiveMembers();
      // Client will handle the excel generation
      res.json(members);
    } catch (error) {
      console.error("Error exporting inactive members:", error);
      res.status(500).json({ message: "Error exporting inactive members" });
    }
  });

  app.get("/api/admin/export/all-members", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.sendStatus(403);
    }
    
    try {
      const members = await storage.getAllMembers();
      // Client will handle the excel generation
      res.json(members);
    } catch (error) {
      console.error("Error exporting all members:", error);
      res.status(500).json({ message: "Error exporting all members" });
    }
  });

  app.get("/api/admin/export/officers", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.sendStatus(403);
    }
    
    try {
      const officers = await storage.getOfficers();
      const officersWithDetails = await Promise.all(
        officers.map(async (officer) => {
          const user = await storage.getUser(officer.userId);
          return {
            ...officer,
            name: user?.name,
            assignedDate: format(new Date(officer.assignedDate), 'yyyy-MM-dd')
          };
        })
      );
      
      // Client will handle the excel generation
      res.json(officersWithDetails);
    } catch (error) {
      console.error("Error exporting officers:", error);
      res.status(500).json({ message: "Error exporting officers" });
    }
  });

  app.get("/api/admin/export/loan-payments", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.sendStatus(403);
    }
    
    try {
      const loans = await storage.getAllActiveLoans();
      const loansWithDetails = await Promise.all(
        loans.map(async (loan) => {
          const payments = await storage.getPaymentsByLoan(loan.id);
          const member = await storage.getUser(loan.userId);
          
          return {
            loan: {
              ...loan,
              memberName: member?.name
            },
            payments: payments.map(payment => ({
              ...payment,
              datePaid: format(new Date(payment.datePaid), 'yyyy-MM-dd')
            }))
          };
        })
      );
      
      // Client will handle the excel generation
      res.json(loansWithDetails);
    } catch (error) {
      console.error("Error exporting loan payments:", error);
      res.status(500).json({ message: "Error exporting loan payments" });
    }
  });

  app.get("/api/admin/export/monthly-income-expenses", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.sendStatus(403);
    }
    
    try {
      const year = parseInt(req.query.year as string) || new Date().getFullYear();
      const month = parseInt(req.query.month as string) || new Date().getMonth() + 1;
      
      const incomes = await storage.getMonthlyIncomeByDate(year, month);
      const expenses = await storage.getMonthlyExpensesByDate(year, month);
      
      // Client will handle the excel generation
      res.json({
        incomes: incomes.map(income => ({
          ...income,
          date: format(new Date(income.date), 'yyyy-MM-dd')
        })),
        expenses: expenses.map(expense => ({
          ...expense,
          date: format(new Date(expense.date), 'yyyy-MM-dd')
        }))
      });
    } catch (error) {
      console.error("Error exporting monthly income/expenses:", error);
      res.status(500).json({ message: "Error exporting monthly income/expenses" });
    }
  });

  // Add new member with required fields and auto-generated password
  app.post("/api/admin/members", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.sendStatus(403);
    }
    
    try {
      const userData = req.body;
      
      // Generate full name from the fields
      userData.name = `${userData.firstName} ${userData.middleName || ''} ${userData.lastName}`.trim();
      
      // Generate password based on LastnameDateofbirth format
      if (userData.lastName && userData.birthdate) {
        const birthDate = new Date(userData.birthdate);
        const formattedDate = format(birthDate, 'MMddyyyy');
        const plainPassword = `${userData.lastName}${formattedDate}`;
        // Hash the password before storing
        userData.password = await hashPassword(plainPassword);
        console.log(`Generated and hashed password for new member: ${userData.lastName} (password details hidden)`);
      } else {
        return res.status(400).json({ message: "Last name and birthdate are required for password generation" });
      }
      
      // Create the user record
      const user = await storage.createUser(userData);
      
      // If capital share amount is provided, create a capital share entry
      if (userData.capitalShareAmount && parseFloat(userData.capitalShareAmount) > 0) {
        const amount = parseFloat(userData.capitalShareAmount);
        await storage.addCapitalShare({
          userId: user.id,
          amount
        });
        
        // Update reserve fund
        const funds = await storage.getFunds() || { id: 1, onhandCash: 0, capitalFund: 0, reserveFund: 0, updatedAt: new Date() };
        await storage.updateFunds({
          reserveFund: funds.reserveFund + amount
        });
      }
      
      res.status(201).json(user);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error creating member:", error);
      res.status(500).json({ message: "Error creating member" });
    }
  });

  const httpServer = createServer(app);
  
  // Set up WebSocket server for officer chat
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  // Store connected clients with their user information
  const clients = new Map();
  
  wss.on('connection', (ws) => {
    let userId: number = 0;
    let userName: string = '';
    let userRole: string = '';
    
    console.log('New WebSocket connection established');
    
    ws.on('message', async (message) => {
      try {
        const data = JSON.parse(message.toString());
        
        // Handle authentication message
        if (data.type === 'auth') {
          userId = data.userId;
          userName = data.userName;
          userRole = data.userRole;
          
          // Store client with user info
          clients.set(ws, { userId, userName, userRole });
          
          console.log(`User authenticated on WebSocket: ${userName} (${userId})`);
          
          // Notify all clients about the new user connection
          const timestamp = new Date().toISOString();
          broadcast({
            type: 'system',
            userId: 0,
            userName: 'System',
            userRole: 'system',
            content: `${userName} has joined the chat`,
            timestamp
          });
          
          // Send connected users list
          const onlineUsers: Array<{userId: number, userName: string, userRole: string}> = [];
          clients.forEach((user, client) => {
            if (client.readyState === WebSocket.OPEN) {
              onlineUsers.push({
                userId: user.userId,
                userName: user.userName,
                userRole: user.userRole
              });
            }
          });
          
          ws.send(JSON.stringify({
            type: 'users',
            users: onlineUsers
          }));
        }
        
        // Handle chat message
        else if (data.type === 'message') {
          if (!userId) {
            // Not authenticated
            ws.send(JSON.stringify({
              type: 'error',
              content: 'You must authenticate first'
            }));
            return;
          }
          
          const timestamp = new Date().toISOString();
          // Broadcast message to all clients
          broadcast({
            type: 'message',
            userId,
            userName,
            userRole,
            content: data.content,
            timestamp
          });
        }
      } catch (error) {
        console.error('Error processing WebSocket message:', error);
        ws.send(JSON.stringify({
          type: 'error',
          content: 'Invalid message format'
        }));
      }
    });
    
    ws.on('close', () => {
      // Get user info before removing from clients map
      const user = clients.get(ws);
      
      if (user) {
        console.log(`WebSocket connection closed for user: ${user.userName} (${user.userId})`);
        
        // Broadcast user disconnect message
        const timestamp = new Date().toISOString();
        broadcast({
          type: 'system',
          userId: 0,
          userName: 'System',
          userRole: 'system',
          content: `${user.userName} has left the chat`,
          timestamp
        });
      } else {
        console.log('WebSocket connection closed for unauthenticated user');
      }
      
      // Remove client from map
      clients.delete(ws);
    });
  });
  
  // Broadcast message to all connected clients
  function broadcast(message: any) {
    const messageStr = JSON.stringify(message);
    
    clients.forEach((user, client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(messageStr);
      }
    });
  }
  
  return httpServer;
}
