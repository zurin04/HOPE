import { pgTable, text, serial, integer, boolean, timestamp, doublePrecision, date } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  firstName: text("first_name"),
  middleName: text("middle_name"),
  lastName: text("last_name"),
  address: text("address"),
  occupation: text("occupation"),
  birthplace: text("birthplace"),
  birthdate: date("birthdate"),
  contactNumber: text("contact_number"),
  email: text("email"),
  civilStatus: text("civil_status"),
  numberOfChildren: integer("number_of_children"),
  parentsName: text("parents_name"),
  sourceOfIncome: text("source_of_income"),
  password: text("password").notNull(),
  role: text("role").default("member").notNull(), // admin or member
  status: text("status").default("active").notNull(), // active or inactive
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});

// Capital Shares table
export const capitalShares = pgTable("capital_shares", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  amount: doublePrecision("amount").notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});

// Loans table
export const loans = pgTable("loans", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  amount: doublePrecision("amount").notNull(),
  balance: doublePrecision("balance").notNull(),
  interest: doublePrecision("interest").notNull(),
  term: integer("term").notNull(), // in months
  schedule: text("schedule").notNull(), // daily, weekly, monthly
  startDate: date("start_date").notNull(),
  status: text("status").default("pending").notNull(), // pending, approved, active, completed, defaulted, rejected
  approvalStatus: text("approval_status").default("pending").notNull(), // pending, approved, rejected
  approvedBy: integer("approved_by").references(() => users.id),
  approvedAt: timestamp("approved_at"),
  approvalNote: text("approval_note"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});

// Payments table
export const payments = pgTable("payments", {
  id: serial("id").primaryKey(),
  loanId: integer("loan_id").references(() => loans.id).notNull(),
  amount: doublePrecision("amount").notNull(),
  datePaid: timestamp("date_paid").defaultNow().notNull(),
  status: text("status").default("pending").notNull(),
  verifiedBy: integer("verified_by").references(() => users.id),
  verifiedAt: timestamp("verified_at"),
  paymentMethod: text("payment_method").default("counter").notNull(),
  paymentNote: text("payment_note")
});

// Cooperative Funds table
export const funds = pgTable("funds", {
  id: serial("id").primaryKey(),
  onhandCash: doublePrecision("onhand_cash").notNull(),
  capitalFund: doublePrecision("capital_fund").notNull(),
  reserveFund: doublePrecision("reserve_fund").notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});

// Officers table
export const officers = pgTable("officers", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  position: text("position").notNull(),
  assignedDate: timestamp("assigned_date").defaultNow().notNull()
});

// News Feed table
export const newsFeed = pgTable("news_feed", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  createdBy: integer("created_by").references(() => users.id).notNull()
});

// Monthly Income table
export const monthlyIncome = pgTable("monthly_income", {
  id: serial("id").primaryKey(),
  amount: doublePrecision("amount").notNull(),
  source: text("source").notNull(),
  date: date("date").notNull(),
  note: text("note"),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

// Monthly Expenses table
export const monthlyExpenses = pgTable("monthly_expenses", {
  id: serial("id").primaryKey(),
  amount: doublePrecision("amount").notNull(),
  category: text("category").notNull(),
  date: date("date").notNull(),
  note: text("note"),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

// Member Savings table
export const memberSavings = pgTable("member_savings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  amount: doublePrecision("amount").notNull(),
  balance: doublePrecision("balance").notNull(),
  transactionType: text("transaction_type").notNull(), // deposit, withdrawal, dividend
  date: timestamp("date").defaultNow().notNull(),
  note: text("note"),
  processedBy: integer("processed_by").references(() => users.id)
});

// Dividend Records table
export const dividendRecords = pgTable("dividend_records", {
  id: serial("id").primaryKey(),
  year: integer("year").notNull(),
  totalAmount: doublePrecision("total_amount").notNull(),
  distributionDate: timestamp("distribution_date").defaultNow().notNull(),
  note: text("note"),
  status: text("status").default("pending").notNull() // pending, completed
});

// Notifications table
export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  title: text("title").notNull(),
  message: text("message").notNull(),
  type: text("type").notNull(), // loan_request, loan_approved, loan_rejected, payment_confirmation, etc.
  relatedId: integer("related_id"), // can be loan ID, payment ID, etc.
  isRead: boolean("is_read").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  capitalShares: many(capitalShares),
  loans: many(loans),
  officers: many(officers),
  newsFeed: many(newsFeed),
  notifications: many(notifications),
  savings: many(memberSavings)
}));

export const notificationsRelations = relations(notifications, ({ one }) => ({
  user: one(users, { fields: [notifications.userId], references: [users.id] })
}));

export const loansRelations = relations(loans, ({ one, many }) => ({
  user: one(users, { fields: [loans.userId], references: [users.id] }),
  payments: many(payments)
}));

export const paymentsRelations = relations(payments, ({ one }) => ({
  loan: one(loans, { fields: [payments.loanId], references: [loans.id] })
}));

export const capitalSharesRelations = relations(capitalShares, ({ one }) => ({
  user: one(users, { fields: [capitalShares.userId], references: [users.id] })
}));

export const officersRelations = relations(officers, ({ one }) => ({
  user: one(users, { fields: [officers.userId], references: [users.id] })
}));

export const newsFeedRelations = relations(newsFeed, ({ one }) => ({
  createdByUser: one(users, { fields: [newsFeed.createdBy], references: [users.id] })
}));

export const memberSavingsRelations = relations(memberSavings, ({ one }) => ({
  user: one(users, { fields: [memberSavings.userId], references: [users.id] }),
  processor: one(users, { fields: [memberSavings.processedBy], references: [users.id] })
}));

// Schemas for validation
export const insertUserSchema = createInsertSchema(users, {
  name: (schema) => schema.min(3, "Name must be at least 3 characters"),
  firstName: (schema) => schema.min(2, "First name must be at least 2 characters"),
  lastName: (schema) => schema.min(2, "Last name must be at least 2 characters"),
  email: (schema) => schema.email("Must provide a valid email").optional(),
  password: (schema) => schema.min(6, "Password must be at least 6 characters"),
  address: (schema) => schema.min(5, "Address must be at least 5 characters"),
  occupation: (schema) => schema.min(2, "Occupation must be at least 2 characters"),
  birthplace: (schema) => schema.min(2, "Birthplace must be at least 2 characters"),
  contactNumber: (schema) => schema.min(7, "Contact number must be at least 7 characters"),
  civilStatus: (schema) => schema.min(2, "Civil status must be at least 2 characters"),
  numberOfChildren: (schema) => schema.optional(),
  parentsName: (schema) => schema.min(2, "Parents name must be at least 2 characters").optional(),
  sourceOfIncome: (schema) => schema.min(2, "Source of income must be at least 2 characters")
}).omit({ id: true, createdAt: true, updatedAt: true });

export const loginUserSchema = z.object({
  email: z.string().email("Must provide a valid email"),
  password: z.string().min(6, "Password must be at least 6 characters")
});

export const insertLoanSchema = createInsertSchema(loans, {
  amount: (schema) => schema.min(1, "Amount must be greater than 0"),
  interest: (schema) => schema.min(0, "Interest cannot be negative"),
  term: (schema) => schema.min(1, "Term must be at least 1 month")
}).omit({ id: true, createdAt: true, updatedAt: true });

export const insertPaymentSchema = createInsertSchema(payments, {
  amount: (schema) => schema.min(1, "Amount must be greater than 0"),
  paymentMethod: (schema) => schema.optional(),
  paymentNote: (schema) => schema.optional()
}).omit({ id: true, datePaid: true, status: true, verifiedBy: true, verifiedAt: true });

export const insertCapitalShareSchema = createInsertSchema(capitalShares, {
  amount: (schema) => schema.min(1, "Amount must be greater than 0")
}).omit({ id: true, updatedAt: true });

export const insertOfficerSchema = createInsertSchema(officers, {
  position: (schema) => schema.min(2, "Position must be at least 2 characters")
}).omit({ id: true, assignedDate: true });

export const insertNewsFeedSchema = createInsertSchema(newsFeed, {
  title: (schema) => schema.min(3, "Title must be at least 3 characters"),
  content: (schema) => schema.min(10, "Content must be at least 10 characters")
}).omit({ id: true, createdAt: true });

export const insertMonthlyIncomeSchema = createInsertSchema(monthlyIncome, {
  amount: (schema) => schema.min(1, "Amount must be greater than 0"),
  source: (schema) => schema.min(3, "Source must be at least 3 characters")
}).omit({ id: true, createdAt: true });

export const insertMonthlyExpensesSchema = createInsertSchema(monthlyExpenses, {
  amount: (schema) => schema.min(1, "Amount must be greater than 0"),
  category: (schema) => schema.min(3, "Category must be at least 3 characters")
}).omit({ id: true, createdAt: true });

export const insertNotificationSchema = createInsertSchema(notifications, {
  title: (schema) => schema.min(3, "Title must be at least 3 characters"),
  message: (schema) => schema.min(10, "Message must be at least 10 characters")
}).omit({ id: true, createdAt: true, isRead: true });

export const insertMemberSavingsSchema = createInsertSchema(memberSavings, {
  amount: (schema) => schema.min(1, "Amount must be greater than 0"),
  transactionType: (schema) => schema.refine(val => ['deposit', 'withdrawal', 'dividend'].includes(val), {
    message: "Transaction type must be 'deposit', 'withdrawal', or 'dividend'"
  })
}).omit({ id: true, date: true, processedBy: true });

export const insertDividendRecordSchema = createInsertSchema(dividendRecords, {
  totalAmount: (schema) => schema.min(1, "Amount must be greater than 0"),
  year: (schema) => schema.refine(val => val > 2000 && val < 2100, {
    message: "Year must be valid"
  })
}).omit({ id: true, distributionDate: true });

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Loan = typeof loans.$inferSelect;
export type InsertLoan = z.infer<typeof insertLoanSchema>;
export type Payment = typeof payments.$inferSelect;
export type InsertPayment = z.infer<typeof insertPaymentSchema>;
export type CapitalShare = typeof capitalShares.$inferSelect;
export type InsertCapitalShare = z.infer<typeof insertCapitalShareSchema>;
export type Officer = typeof officers.$inferSelect;
export type InsertOfficer = z.infer<typeof insertOfficerSchema>;
export type NewsFeed = typeof newsFeed.$inferSelect;
export type InsertNewsFeed = z.infer<typeof insertNewsFeedSchema>;
export type Fund = typeof funds.$inferSelect;
export type MonthlyIncome = typeof monthlyIncome.$inferSelect;
export type InsertMonthlyIncome = z.infer<typeof insertMonthlyIncomeSchema>;
export type MonthlyExpense = typeof monthlyExpenses.$inferSelect;
export type InsertMonthlyExpense = z.infer<typeof insertMonthlyExpensesSchema>;
export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type MemberSavings = typeof memberSavings.$inferSelect;
export type InsertMemberSavings = z.infer<typeof insertMemberSavingsSchema>;
export type DividendRecord = typeof dividendRecords.$inferSelect;
export type InsertDividendRecord = z.infer<typeof insertDividendRecordSchema>;
export type LoginData = z.infer<typeof loginUserSchema>;
