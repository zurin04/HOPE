import { db } from "./db/index.js";
import { memberSavings } from "./shared/schema.js";
import { eq, desc } from "drizzle-orm";

async function debugSavings() {
  console.log("=== Debugging Savings Display Issue ===");
  
  // Check database connection and data
  console.log("\n1. Checking database data...");
  const allSavings = await db.select().from(memberSavings);
  console.log("All member savings records:", allSavings);
  
  // Test getMemberSavingsBalance logic directly
  console.log("\n2. Testing savings balance calculation for user 2...");
  const latestSavings = await db.select()
    .from(memberSavings)
    .where(eq(memberSavings.userId, 2))
    .orderBy(desc(memberSavings.date))
    .limit(1);
  
  console.log("Latest savings record for user 2:", latestSavings);
  
  if (latestSavings.length > 0) {
    console.log("Balance from latest record:", latestSavings[0].balance);
  } else {
    console.log("No savings records found for user 2");
  }
  
  // Test for all users with savings
  console.log("\n3. Testing all users with savings...");
  for (const userId of [2, 3, 4]) {
    const userSavings = await db.select()
      .from(memberSavings)
      .where(eq(memberSavings.userId, userId))
      .orderBy(desc(memberSavings.date))
      .limit(1);
    
    const balance = userSavings.length > 0 ? userSavings[0].balance : 0;
    console.log(`User ${userId} balance: ${balance}`);
  }
  
  process.exit(0);
}

debugSavings().catch(console.error);