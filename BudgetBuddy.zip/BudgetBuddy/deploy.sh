#!/bin/bash

# HOPEMPC Production Deployment Script
# Optimized one-click deployment for Ubuntu VPS

set -e

echo "======================================"
echo "HOPEMPC Production Deployment"
echo "======================================"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

print_status() { echo -e "${GREEN}[INFO]${NC} $1"; }
print_warning() { echo -e "${YELLOW}[WARN]${NC} $1"; }
print_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# Check prerequisites
[[ $EUID -eq 0 ]] && { print_error "Do not run as root. Use a regular user with sudo privileges."; exit 1; }
command -v sudo >/dev/null || { print_error "sudo is required but not installed."; exit 1; }

# Install system dependencies
print_status "Installing system dependencies..."
sudo apt update -y && sudo apt install -y curl wget gnupg postgresql postgresql-contrib nginx

# Install Node.js 20
if ! command -v node &>/dev/null; then
    print_status "Installing Node.js 20..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
    sudo apt install -y nodejs
fi

# Install PM2
sudo npm install -g pm2 2>/dev/null || print_warning "PM2 already installed"

# Start services
sudo systemctl enable --now postgresql nginx

# Setup application
APP_DIR="/var/www/hopempc"
print_status "Setting up application..."
sudo mkdir -p $APP_DIR && sudo chown $USER:$USER $APP_DIR
cp -r . $APP_DIR/ && cd $APP_DIR

# Generate secure credentials
DB_PASSWORD=$(openssl rand -base64 32)
SESSION_SECRET=$(openssl rand -hex 32)

# Create database and user
print_status "Setting up PostgreSQL database..."
sudo -u postgres psql << EOF
DROP DATABASE IF EXISTS hopempc_db;
DROP USER IF EXISTS hopempc_user;
CREATE USER hopempc_user WITH PASSWORD '$DB_PASSWORD' SUPERUSER;
CREATE DATABASE hopempc_db OWNER hopempc_user;
GRANT ALL PRIVILEGES ON DATABASE hopempc_db TO hopempc_user;
\q
EOF

# Create environment file
print_status "Creating environment configuration..."
cat > .env << ENV
DATABASE_URL=postgresql://hopempc_user:$DB_PASSWORD@localhost:5432/hopempc_db
SESSION_SECRET=$SESSION_SECRET
NODE_ENV=production
PORT=5000
ENV

# Install dependencies 
print_status "Installing dependencies..."
npm install

# Setup database schema and seed data
print_status "Initializing database..."
export DATABASE_URL="postgresql://hopempc_user:$DB_PASSWORD@localhost:5432/hopempc_db"
export SESSION_SECRET
export NODE_ENV=production

npm run db:push
npx tsx db/simple-seed.ts

# Fix any password format issues
print_status "Fixing password formats..."
npx tsx db/fix-all-passwords.ts 2>/dev/null || echo "Password fix utility not needed or already applied"

# Build application
print_status "Building application..."
npm run build

# Configure PM2 and services
print_status "Configuring services..."
mkdir -p logs

cat > ecosystem.config.cjs << EOF
module.exports = {
  apps: [{
    name: 'hopempc',
    script: 'npm',
    args: 'start',
    instances: 1,
    autorestart: true,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      DATABASE_URL: 'postgresql://hopempc_user:$DB_PASSWORD@localhost:5432/hopempc_db',
      SESSION_SECRET: '$SESSION_SECRET'
    },
    error_file: './logs/err.log',
    out_file: './logs/out.log',
    log_file: './logs/combined.log'
  }]
}
EOF

# Configure Nginx
sudo tee /etc/nginx/sites-available/hopempc > /dev/null << 'EOF'
server {
    listen 80;
    server_name _;
    client_max_body_size 100M;
    
    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
    
    add_header X-Frame-Options DENY;
    add_header X-Content-Type-Options nosniff;
}
EOF

sudo ln -sf /etc/nginx/sites-available/hopempc /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t && sudo systemctl reload nginx

# Start application
print_status "Starting application with PM2..."
pm2 delete all 2>/dev/null || true
pm2 start ecosystem.config.cjs
pm2 save

# Setup PM2 startup
print_status "Configuring PM2 auto-startup..."
sudo env PATH=$PATH:/usr/bin /usr/lib/node_modules/pm2/bin/pm2 startup systemd -u $USER --hp $HOME

# Verify application is running
print_status "Verifying application startup..."
sleep 5
if pm2 list | grep -q "hopempc.*online"; then
    print_status "Application started successfully!"
else
    print_error "Application failed to start. Check logs with: pm2 logs hopempc"
    exit 1
fi

# Setup security and management
print_status "Finalizing setup..."
sudo ufw --force enable
sudo ufw allow 22,80,443/tcp

# Create management script
cat > manage.sh << 'SCRIPT'
#!/bin/bash
case "$1" in
    start|stop|restart) pm2 $1 hopempc ;;
    status) pm2 status && pm2 logs hopempc --lines 10 ;;
    logs) pm2 logs hopempc ;;
    update) git pull && npm install && npm run db:push && npm run build && pm2 restart hopempc ;;
    backup) 
        mkdir -p /var/backups/hopempc
        BACKUP_FILE="/var/backups/hopempc/backup_$(date +%Y%m%d_%H%M%S).sql"
        PGPASSWORD=$DB_PASSWORD pg_dump -h localhost -U hopempc_user hopempc_db > $BACKUP_FILE
        echo "Backup saved to: $BACKUP_FILE"
        ;;
    *) echo "Usage: $0 {start|stop|restart|status|logs|update|backup}" ;;
esac
SCRIPT
chmod +x manage.sh

# Setup automatic backups
(crontab -l 2>/dev/null | grep -v "hopempc backup"; echo "0 2 * * * $APP_DIR/manage.sh backup") | crontab -

# Get server info
SERVER_IP=$(curl -s ifconfig.me 2>/dev/null || hostname -I | awk '{print $1}')

# Create deployment info
cat > deployment-info.txt << INFO
HOPEMPC Deployment Complete
===========================
Date: $(date)
Server: http://$SERVER_IP
Database Password: $DB_PASSWORD

Default Credentials:
- Admin: admin@hopempc.org / admin123
- Member: member@hopempc.org / member123

Management:
- ./manage.sh status    # Check status
- ./manage.sh restart   # Restart app
- ./manage.sh logs      # View logs
- ./manage.sh update    # Update app
- ./manage.sh backup    # Backup database

Services:
- nginx: sudo systemctl status nginx
- postgresql: sudo systemctl status postgresql
- pm2: pm2 status

IMPORTANT: Change default passwords after first login!
INFO

echo ""
print_status "Deployment completed successfully!"
print_status "Application URL: http://$SERVER_IP"
print_status "Admin login: admin@hopempc.org / admin123"
print_status "Check ./deployment-info.txt for details"
echo ""