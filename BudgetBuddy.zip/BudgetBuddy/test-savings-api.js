// Quick test to check savings API response
import { storage } from './server/storage.js';

async function testSavingsBalance() {
  console.log('Testing savings balance for user ID 2 (John Doe)...');
  
  try {
    const balance = await storage.getMemberSavingsBalance(2);
    console.log('Balance result:', balance);
    
    const savings = await storage.getMemberSavings(2);
    console.log('Savings transactions:', savings);
    
    console.log('API response would be:', { transactions: savings, balance });
  } catch (error) {
    console.error('Error:', error);
  }
  
  process.exit(0);
}

testSavingsBalance();