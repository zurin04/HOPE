import { scrypt, randomBytes } from "crypto";
import { promisify } from "util";
import { db } from "./index.js";
import { users } from "../shared/schema.js";
import { eq } from "drizzle-orm";

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16).toString("hex");
  const derivedKey = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${salt}.${derivedKey.toString("hex")}`;
}

async function resetAdminPassword() {
  try {
    console.log("Resetting admin password...");
    
    const email = "sebuguerojanmark@gmail.com";
    const newPassword = "Janmark@25";
    
    // Hash the new password
    const hashedPassword = await hashPassword(newPassword);
    console.log("Password hashed successfully");
    
    // Update the password in the database
    const result = await db
      .update(users)
      .set({ password: hashedPassword })
      .where(eq(users.email, email))
      .returning();
    
    if (result.length > 0) {
      console.log(`Password successfully reset for user: ${email}`);
      console.log(`User details:`, {
        id: result[0].id,
        name: result[0].name,
        email: result[0].email,
        role: result[0].role
      });
    } else {
      console.log("No user found with that email address");
    }
    
    process.exit(0);
  } catch (error) {
    console.error("Error resetting password:", error);
    process.exit(1);
  }
}

resetAdminPassword();