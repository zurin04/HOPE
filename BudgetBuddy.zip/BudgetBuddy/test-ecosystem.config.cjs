module.exports = {
  apps: [{
    name: 'hopempc',
    script: 'npm',
    args: 'start',
    instances: 1,
    autorestart: true,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      DATABASE_URL: 'postgresql://hopempc_user:Of/Buuw94TjptF04FNr6pXrP0nvXnD0nUJB7YnsHm90=@localhost:5432/hopempc_db',
      SESSION_SECRET: '72a6c4ec7a4ffde31ed69895e0e0e02add681ab92bc996b15ebb29bde9368914'
    },
    error_file: './logs/err.log',
    out_file: './logs/out.log',
    log_file: './logs/combined.log'
  }]
}
