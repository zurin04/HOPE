# HOPEMPC Production Deployment

Simple one-click deployment for Ubuntu VPS servers.

## Quick Deployment

```bash
chmod +x deploy.sh
./deploy.sh
```

The script automatically:
- Installs Node.js, PostgreSQL, Nginx, PM2
- Sets up database with secure credentials
- Builds and deploys the application
- Configures reverse proxy and firewall
- Creates management utilities

## Post-Deployment

Access your application at `http://YOUR_SERVER_IP`

Default credentials:
- Admin: `admin@hopempc.org` / `admin123`
- Member: `member@hopempc.org` / `member123`

**Important:** Change default passwords immediately after first login.

## Management

Use the provided management script:

```bash
./manage.sh status    # Check application status
./manage.sh restart   # Restart application
./manage.sh logs      # View application logs
./manage.sh update    # Update application
./manage.sh backup    # Backup database
```

## Services

- **Application**: PM2 process manager
- **Database**: PostgreSQL
- **Web Server**: Nginx reverse proxy
- **Backups**: Automated daily at 2 AM

## SSL Setup

For production with domain name:

```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d yourdomain.com
```

## Troubleshooting

Check service status:
```bash
sudo systemctl status nginx postgresql
pm2 status
pm2 logs hopempc
```

For issues, check:
- `./deployment-info.txt` for credentials
- `./logs/` directory for application logs
- Database connectivity with provided credentials