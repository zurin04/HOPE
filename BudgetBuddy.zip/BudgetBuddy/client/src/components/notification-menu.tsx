import { useState } from "react";
import {
  BellIcon,
  CheckCircleIcon,
  XCircleIcon,
  CheckIcon,
} from "lucide-react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { formatDistanceToNow } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

type Notification = {
  id: number;
  title: string;
  message: string;
  type: string;
  relatedId: number | null;
  isRead: boolean;
  createdAt: string;
};

function NotificationIcon({ type }: { type: string }) {
  switch (type) {
    case "loan_request":
      return <BellIcon className="h-4 w-4 text-blue-500" />;
    case "loan_approved":
      return <CheckCircleIcon className="h-4 w-4 text-green-500" />;
    case "loan_rejected":
      return <XCircleIcon className="h-4 w-4 text-red-500" />;
    case "payment_confirmation":
      return <CheckIcon className="h-4 w-4 text-green-500" />;
    default:
      return <BellIcon className="h-4 w-4" />;
  }
}

export function NotificationMenu() {
  const [isOpen, setIsOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Custom event to open loan approval dialog
  const openLoanApprovalDialog = (loanId: number) => {
    const event = new CustomEvent('openLoanApproval', { detail: { loanId } });
    window.dispatchEvent(event);
  };

  const { data: notifications = [], refetch } = useQuery<Notification[]>({
    queryKey: ["/api/notifications"],
    refetchInterval: 30000, // Refetch every 30 seconds
  });

  const { data: unreadNotifications = [] } = useQuery<Notification[]>({
    queryKey: ["/api/notifications/unread"],
    refetchInterval: 30000, // Refetch every 30 seconds
  });

  const markAsReadMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("POST", `/api/notifications/${id}/read`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
      queryClient.invalidateQueries({ queryKey: ["/api/notifications/unread"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to mark notification as read: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  const markAllAsReadMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/notifications/read-all");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
      queryClient.invalidateQueries({ queryKey: ["/api/notifications/unread"] });
      toast({
        title: "Success",
        description: "All notifications marked as read",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to mark all notifications as read: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  const handleMarkAsRead = (id: number, e: React.MouseEvent) => {
    e.stopPropagation();
    markAsReadMutation.mutate(id);
  };

  const handleMarkAllAsRead = (e: React.MouseEvent) => {
    e.stopPropagation();
    markAllAsReadMutation.mutate();
  };

  const getNotificationTime = (date: string) => {
    try {
      return formatDistanceToNow(new Date(date), { addSuffix: true });
    } catch (e) {
      return "recently";
    }
  };

  return (
    <DropdownMenu open={isOpen} onOpenChange={setIsOpen}>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="relative">
          <BellIcon className="h-5 w-5" />
          {unreadNotifications.length > 0 && (
            <Badge
              variant="destructive"
              className="absolute -top-2 -right-1 h-5 min-w-5 flex items-center justify-center p-0 text-xs"
            >
              {unreadNotifications.length}
            </Badge>
          )}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-80">
        <div className="flex items-center justify-between p-2 border-b">
          <h3 className="font-medium">Notifications</h3>
          {unreadNotifications.length > 0 && (
            <Button
              variant="ghost"
              size="sm"
              className="text-xs"
              onClick={handleMarkAllAsRead}
              disabled={markAllAsReadMutation.isPending}
            >
              Mark all as read
            </Button>
          )}
        </div>
        <div className="max-h-[400px] overflow-y-auto">
          {notifications.length === 0 ? (
            <div className="p-4 text-center text-sm text-muted-foreground">
              No notifications
            </div>
          ) : (
            notifications.map((notification) => (
              <DropdownMenuItem
                key={notification.id}
                className={`flex flex-col items-start p-3 ${!notification.isRead ? "bg-muted/50" : ""}`}
                onClick={() => {
                  // For loan request notifications, open the approval dialog
                  if (notification.type === "loan_request" && notification.relatedId) {
                    openLoanApprovalDialog(notification.relatedId);
                    setIsOpen(false); // Close dropdown after click
                    markAsReadMutation.mutate(notification.id); // Mark as read when acted upon
                  }
                }}
              >
                <div className="flex items-start w-full">
                  <div className="mr-2 mt-1">
                    <NotificationIcon type={notification.type} />
                  </div>
                  <div className="flex-1">
                    <div className="flex justify-between w-full">
                      <p className="font-medium text-sm">{notification.title}</p>
                      <span className="text-xs text-muted-foreground">
                        {getNotificationTime(notification.createdAt)}
                      </span>
                    </div>
                    <p className="text-sm mt-1">{notification.message}</p>
                    {notification.type === "loan_request" && notification.relatedId && (
                      <p className="text-xs text-blue-500 mt-1 cursor-pointer">
                        Click to review loan application
                      </p>
                    )}
                  </div>
                </div>
                {!notification.isRead && (
                  <div className="flex justify-end w-full mt-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-xs"
                      onClick={(e) => handleMarkAsRead(notification.id, e)}
                      disabled={markAsReadMutation.isPending}
                    >
                      Mark as read
                    </Button>
                  </div>
                )}
              </DropdownMenuItem>
            ))
          )}
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
