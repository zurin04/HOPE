import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import { AlertTriangle, X, Calendar, DollarSign } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
type OverdueLoan = {
  id: number;
  amount: number;
  balance: number;
  term: number;
  startDate: string;
  status: string;
  dueDate: string;
  remainingBalance: number;
  purpose?: string;
};

export function LoanDueNotification() {
  const [showDialog, setShowDialog] = useState(false);

  // Check for overdue loans
  const { data: overdueLoans } = useQuery<OverdueLoan[]>({
    queryKey: ["/api/members/loans/overdue"],
    refetchInterval: 30000, // Check every 30 seconds
  });

  useEffect(() => {
    if (overdueLoans && overdueLoans.length > 0 && !showDialog) {
      setShowDialog(true);
    }
  }, [overdueLoans, showDialog]);

  const calculateDaysOverdue = (dueDate: string) => {
    const due = new Date(dueDate);
    const today = new Date();
    const diffTime = today.getTime() - due.getTime();
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  };

  if (!overdueLoans || overdueLoans.length === 0) {
    return null;
  }

  return (
    <Dialog open={showDialog} onOpenChange={setShowDialog}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-destructive">
            <AlertTriangle className="h-5 w-5" />
            Loan Payment Due
          </DialogTitle>
          <DialogDescription>
            You have {overdueLoans.length} overdue loan{overdueLoans.length > 1 ? 's' : ''} that require immediate attention.
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          {overdueLoans.map((loan) => (
            <Card key={loan.id} className="border-destructive/20">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center justify-between">
                  <span>Loan #{loan.id}</span>
                  <Badge variant="destructive">
                    {calculateDaysOverdue(loan.dueDate!)} days overdue
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex items-center gap-2 text-sm">
                  <DollarSign className="h-4 w-4 text-muted-foreground" />
                  <span>Amount: ₱{loan.amount.toLocaleString()}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <DollarSign className="h-4 w-4 text-muted-foreground" />
                  <span>Remaining: ₱{loan.remainingBalance.toLocaleString()}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <span>Due: {format(new Date(loan.dueDate), 'PPP')}</span>
                </div>
                {loan.purpose && (
                  <div className="text-sm text-muted-foreground">
                    Purpose: {loan.purpose}
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="flex justify-between gap-2 pt-4">
          <Button variant="outline" onClick={() => setShowDialog(false)}>
            Remind Me Later
          </Button>
          <Button onClick={() => {
            setShowDialog(false);
            window.location.href = '/payments';
          }}>
            Make Payment
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}