import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import AdminLayout from "@/layouts/admin-layout";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";
import { ArrowLeft, Loader2, Save, UserPlus } from "lucide-react";
import { Link } from "wouter";

const MemberRegistration = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Form state
  const [formData, setFormData] = useState({
    firstName: "",
    middleName: "",
    lastName: "",
    address: "",
    occupation: "",
    birthplace: "",
    birthdate: "",
    contactNumber: "",
    email: "",
    civilStatus: "",
    numberOfChildren: "",
    parentsName: "",
    sourceOfIncome: "",
    capitalShareAmount: ""
  });

  // State for registration success
  const [registrationSuccess, setRegistrationSuccess] = useState(false);
  const [registeredUser, setRegisteredUser] = useState<{id: number, name: string} | null>(null);
  
  // Mutation for creating a new member
  const createMemberMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      // Format the data to match the expected API format
      let numChildren = 0;
      if (data.numberOfChildren && data.numberOfChildren !== "") {
        numChildren = parseInt(data.numberOfChildren);
      }

      let capitalAmount = 0;
      if (data.capitalShareAmount && data.capitalShareAmount !== "") {
        capitalAmount = parseFloat(data.capitalShareAmount);
      }
      
      const memberData = {
        firstName: data.firstName,
        middleName: data.middleName,
        lastName: data.lastName,
        address: data.address,
        occupation: data.occupation,
        birthplace: data.birthplace,
        birthdate: data.birthdate,
        contactNumber: data.contactNumber,
        email: data.email,
        civilStatus: data.civilStatus,
        numberOfChildren: numChildren,
        parentsName: data.parentsName,
        sourceOfIncome: data.sourceOfIncome,
        capitalShareAmount: capitalAmount,
        role: "member",
        status: "active"
      };
      
      const res = await apiRequest("POST", "/api/admin/members", memberData);
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.message || "Failed to create member");
      }
      return await res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Success",
        description: "Member registered successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/members"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/members/active"] });
      
      // Set success state
      setRegistrationSuccess(true);
      setRegisteredUser({
        id: data.id,
        name: `${data.firstName} ${data.lastName}`
      });
      
      // Reset form
      setFormData({
        firstName: "",
        middleName: "",
        lastName: "",
        address: "",
        occupation: "",
        birthplace: "",
        birthdate: "",
        contactNumber: "",
        email: "",
        civilStatus: "",
        numberOfChildren: "",
        parentsName: "",
        sourceOfIncome: "",
        capitalShareAmount: ""
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Comprehensive validation
    const requiredFields = [
      { field: 'firstName', label: 'First Name' },
      { field: 'lastName', label: 'Last Name' },
      { field: 'birthdate', label: 'Birthdate' },
      { field: 'birthplace', label: 'Birthplace' },
      { field: 'address', label: 'Address' },
      { field: 'contactNumber', label: 'Contact Number' },
      { field: 'occupation', label: 'Occupation' },
      { field: 'sourceOfIncome', label: 'Source of Income' },
      { field: 'civilStatus', label: 'Civil Status' },
      { field: 'capitalShareAmount', label: 'Capital Share Amount' }
    ];
    
    const missingFields = requiredFields.filter(field => !formData[field.field as keyof typeof formData]);
    
    if (missingFields.length > 0) {
      toast({
        title: "Validation Error",
        description: `Please fill in the following required fields: ${missingFields.map(f => f.label).join(', ')}`,
        variant: "destructive",
      });
      return;
    }
    
    // Validate capital share amount
    if (parseFloat(formData.capitalShareAmount) <= 0) {
      toast({
        title: "Validation Error",
        description: "Capital Share Amount must be greater than zero",
        variant: "destructive",
      });
      return;
    }
    
    createMemberMutation.mutate(formData);
  };

  // Generate password preview (Lastname + DateOfBirth format)
  const generatePasswordPreview = () => {
    if (formData.lastName && formData.birthdate) {
      try {
        const birthDate = new Date(formData.birthdate);
        const formattedDate = format(birthDate, "MMddyyyy");
        return `${formData.lastName}${formattedDate}`;
      } catch (error) {
        return "Invalid date format";
      }
    }
    return "";
  };

  return (
    <AdminLayout>
      <div className="container mx-auto py-6">
        {registrationSuccess && registeredUser ? (
          <Card className="max-w-4xl mx-auto shadow-md border-green-500 border-2">
            <CardHeader className="bg-green-500 text-white">
              <CardTitle className="flex items-center">
                <span className="mr-2">✓</span>
                Registration Successful
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="text-center py-8">
                <p className="text-xl mb-4">Member <strong>{registeredUser.name}</strong> has been successfully registered!</p>
                <p className="mb-6">ID: {registeredUser.id}</p>
                <div className="flex justify-center space-x-4">
                  <Link href="/admin/members" className="bg-primary hover:bg-primary/90 text-white px-4 py-2 rounded-md transition flex items-center">
                    <ArrowLeft className="mr-2" size={16} /> Return to Members List
                  </Link>
                  <Button 
                    onClick={() => {
                      setRegistrationSuccess(false);
                      setRegisteredUser(null);
                    }}
                  >
                    Register Another Member
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ) : (
          <Card className="max-w-4xl mx-auto shadow-md">
          <CardHeader className="bg-primary text-white">
            <div className="flex justify-between items-center mb-2">
              <Link href="/admin/members" className="text-white hover:text-white/80 transition flex items-center">
                <ArrowLeft className="mr-1" size={16} /> Back to Members List
              </Link>
            </div>
            <CardTitle className="flex items-center">
              <UserPlus className="mr-2" size={24} />
              New Member Registration
            </CardTitle>
            <CardDescription className="text-white/80">
              Register a new cooperative member with complete details
            </CardDescription>
          </CardHeader>

          <form onSubmit={handleSubmit}>
            <CardContent className="grid gap-6 pt-6">
              {/* Personal Information */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold border-b pb-2">Personal Information</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">First Name *</label>
                    <input
                      type="text"
                      name="firstName"
                      value={formData.firstName}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border rounded-md border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-primary"
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Middle Name</label>
                    <input
                      type="text"
                      name="middleName"
                      value={formData.middleName}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border rounded-md border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Last Name *</label>
                    <input
                      type="text"
                      name="lastName"
                      value={formData.lastName}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border rounded-md border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-primary"
                      required
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Birthplace *</label>
                    <input
                      type="text"
                      name="birthplace"
                      value={formData.birthplace}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border rounded-md border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-primary"
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Birthdate *</label>
                    <input
                      type="date"
                      name="birthdate"
                      value={formData.birthdate}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border rounded-md border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-primary"
                      required
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Contact Number *</label>
                    <input
                      type="text"
                      name="contactNumber"
                      value={formData.contactNumber}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border rounded-md border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-primary"
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Email (Optional)</label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border rounded-md border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">Complete Address *</label>
                  <textarea
                    name="address"
                    value={formData.address}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border rounded-md border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-primary"
                    rows={2}
                    required
                  />
                </div>
              </div>
              
              {/* Family Information */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold border-b pb-2">Family Information</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Civil Status *</label>
                    <select
                      name="civilStatus"
                      value={formData.civilStatus}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border rounded-md border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-primary"
                      required
                    >
                      <option value="">Select Civil Status</option>
                      <option value="Single">Single</option>
                      <option value="Married">Married</option>
                      <option value="Widowed">Widowed</option>
                      <option value="Separated">Separated</option>
                      <option value="Divorced">Divorced</option>
                    </select>
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Number of Children</label>
                    <input
                      type="number"
                      name="numberOfChildren"
                      value={formData.numberOfChildren}
                      onChange={handleInputChange}
                      min="0"
                      className="w-full px-3 py-2 border rounded-md border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">Parents' Names</label>
                  <input
                    type="text"
                    name="parentsName"
                    value={formData.parentsName}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border rounded-md border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-primary"
                    placeholder="Father's name and Mother's name"
                  />
                </div>
              </div>
              
              {/* Financial Information */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold border-b pb-2">Financial Information</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Occupation *</label>
                    <input
                      type="text"
                      name="occupation"
                      value={formData.occupation}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border rounded-md border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-primary"
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Source of Income *</label>
                    <input
                      type="text"
                      name="sourceOfIncome"
                      value={formData.sourceOfIncome}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border rounded-md border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-primary"
                      required
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">Initial Capital Share Amount (CBU) *</label>
                  <input
                    type="number"
                    name="capitalShareAmount"
                    value={formData.capitalShareAmount}
                    onChange={handleInputChange}
                    min="0"
                    step="0.01"
                    className="w-full px-3 py-2 border rounded-md border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-primary"
                    required
                  />
                  <p className="text-xs text-gray-500">This amount will be allocated to the reserve fund.</p>
                </div>
              </div>
              
              {/* Account Information Preview */}
              <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-md">
                <h3 className="text-lg font-semibold mb-2">Account Information Preview</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm font-medium">Username:</p>
                    <p className="text-sm">{formData.email || "(Will use email when provided)"}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium">Generated Password:</p>
                    <p className="text-sm font-mono bg-gray-100 dark:bg-gray-700 p-1 rounded">
                      {generatePasswordPreview() || "(Requires last name and birthdate)"}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      Password format: LastnameBirthdate (e.g., SmithMMDDYYYY)
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>

            <CardFooter className="flex justify-between border-t p-6">
              <Button
                type="button"
                variant="outline"
                onClick={() => setFormData({
                  firstName: "",
                  middleName: "",
                  lastName: "",
                  address: "",
                  occupation: "",
                  birthplace: "",
                  birthdate: "",
                  contactNumber: "",
                  email: "",
                  civilStatus: "",
                  numberOfChildren: "",
                  parentsName: "",
                  sourceOfIncome: "",
                  capitalShareAmount: ""
                })}
              >
                Reset
              </Button>
              <Button
                type="submit"
                disabled={createMemberMutation.isPending}
              >
                {createMemberMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Registering...
                  </>
                ) : (
                  <>
                    <Save className="mr-2 h-4 w-4" />
                    Register Member
                  </>
                )}
              </Button>
            </CardFooter>
          </form>
        </Card>
        )}
      </div>
    </AdminLayout>
  );
};

export default MemberRegistration;