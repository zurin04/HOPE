import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import { FileDown, Printer } from "lucide-react";

import AdminLayout from "@/layouts/admin-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { User, Loan, Payment, MonthlyIncome, MonthlyExpense } from "@shared/schema";

export default function AdminReports() {
  const [activeTab, setActiveTab] = useState("financial");
  const [year, setYear] = useState(new Date().getFullYear());
  const [month, setMonth] = useState(new Date().getMonth() + 1);
  
  // Fetch members
  const { data: members, isLoading: isLoadingMembers } = useQuery<User[]>({
    queryKey: ["/api/admin/members/active"],
  });
  
  // Fetch loans
  const { data: loans, isLoading: isLoadingLoans } = useQuery<Loan[]>({
    queryKey: ["/api/admin/loans"],
  });
  
  // Fetch incomes
  const { data: incomes, isLoading: isLoadingIncomes } = useQuery<MonthlyIncome[]>({
    queryKey: ["/api/admin/income", year, month],
  });
  
  // Fetch expenses
  const { data: expenses, isLoading: isLoadingExpenses } = useQuery<MonthlyExpense[]>({
    queryKey: ["/api/admin/expenses", year, month],
  });
  
  // Calculate summaries
  const totalMembers = members?.length || 0;
  const totalActiveLoans = loans?.filter(loan => loan.status === "active").length || 0;
  const totalLoanAmount = loans?.reduce((sum, loan) => sum + loan.amount, 0) || 0;
  const totalOutstandingLoans = loans?.filter(loan => loan.status === "active")
    .reduce((sum, loan) => sum + loan.balance, 0) || 0;
  
  const totalIncome = incomes?.reduce((sum, income) => sum + income.amount, 0) || 0;
  const totalExpenses = expenses?.reduce((sum, expense) => sum + expense.amount, 0) || 0;
  const netIncome = totalIncome - totalExpenses;
  
  // Group loans by status
  const loansByStatus = loans?.reduce((acc, loan) => {
    if (!acc[loan.status]) {
      acc[loan.status] = [];
    }
    acc[loan.status].push(loan);
    return acc;
  }, {} as Record<string, Loan[]>) || {};
  
  const handlePrint = () => {
    window.print();
  };
  
  const handleExportExcel = () => {
    // This would normally export to Excel - for this example, we'll just show a message
    alert("Exporting to Excel... This feature would be implemented with the xlsx library.");
  };
  
  const months = [
    { value: 1, label: 'January' },
    { value: 2, label: 'February' },
    { value: 3, label: 'March' },
    { value: 4, label: 'April' },
    { value: 5, label: 'May' },
    { value: 6, label: 'June' },
    { value: 7, label: 'July' },
    { value: 8, label: 'August' },
    { value: 9, label: 'September' },
    { value: 10, label: 'October' },
    { value: 11, label: 'November' },
    { value: 12, label: 'December' },
  ];
  
  return (
    <AdminLayout>
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Reports</h1>
        <div className="flex space-x-2">
          <Button variant="outline" onClick={handlePrint}>
            <Printer className="h-4 w-4 mr-2" /> Print
          </Button>
          <Button variant="outline" onClick={handleExportExcel}>
            <FileDown className="h-4 w-4 mr-2" /> Export
          </Button>
        </div>
      </div>
      
      <div className="flex items-center space-x-4 my-4">
        <Select value={month.toString()} onValueChange={(value) => setMonth(parseInt(value))}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Month" />
          </SelectTrigger>
          <SelectContent>
            {months.map(month => (
              <SelectItem key={month.value} value={month.value.toString()}>
                {month.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        
        <Select value={year.toString()} onValueChange={(value) => setYear(parseInt(value))}>
          <SelectTrigger className="w-[120px]">
            <SelectValue placeholder="Year" />
          </SelectTrigger>
          <SelectContent>
            {[2023, 2024, 2025].map(year => (
              <SelectItem key={year} value={year.toString()}>
                {year}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full mt-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="financial">Financial Summary</TabsTrigger>
          <TabsTrigger value="loans">Loan Report</TabsTrigger>
          <TabsTrigger value="members">Member Report</TabsTrigger>
        </TabsList>
        
        <TabsContent value="financial" className="space-y-4">
          <div className="print-section">
            <div className="text-center mb-8 print-only">
              <h2 className="text-2xl font-bold">Financial Report</h2>
              <p className="text-muted-foreground">
                For the period of {months.find(m => m.value === month)?.label} {year}
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Total Income</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-600">
                    ₱{totalIncome.toFixed(2)}
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Total Expenses</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-red-600">
                    ₱{totalExpenses.toFixed(2)}
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Net Income</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className={`text-2xl font-bold ${netIncome >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    ₱{netIncome.toFixed(2)}
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Outstanding Loans</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    ₱{totalOutstandingLoans.toFixed(2)}
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <h3 className="text-xl font-bold mb-4">Income Breakdown</h3>
            <Card className="mb-8">
              <CardContent className="pt-6">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Source</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead className="text-right">Amount</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {isLoadingIncomes ? (
                      Array.from({ length: 3 }).map((_, i) => (
                        <TableRow key={i}>
                          <TableCell><Skeleton className="h-6 w-24" /></TableCell>
                          <TableCell><Skeleton className="h-6 w-32" /></TableCell>
                          <TableCell><Skeleton className="h-6 w-48" /></TableCell>
                          <TableCell><Skeleton className="h-6 w-20" /></TableCell>
                        </TableRow>
                      ))
                    ) : incomes && incomes.length > 0 ? (
                      incomes.map((income) => (
                        <TableRow key={income.id}>
                          <TableCell>{format(new Date(income.date), 'MMM d, yyyy')}</TableCell>
                          <TableCell>{income.source}</TableCell>
                          <TableCell>{income.note || '-'}</TableCell>
                          <TableCell className="text-right font-medium">₱{income.amount.toFixed(2)}</TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={4} className="text-center">
                          No income data available for this period.
                        </TableCell>
                      </TableRow>
                    )}
                    {incomes && incomes.length > 0 && (
                      <TableRow className="font-bold">
                        <TableCell colSpan={3} className="text-right">Total</TableCell>
                        <TableCell className="text-right">₱{totalIncome.toFixed(2)}</TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
            
            <h3 className="text-xl font-bold mb-4">Expense Breakdown</h3>
            <Card>
              <CardContent className="pt-6">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead className="text-right">Amount</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {isLoadingExpenses ? (
                      Array.from({ length: 3 }).map((_, i) => (
                        <TableRow key={i}>
                          <TableCell><Skeleton className="h-6 w-24" /></TableCell>
                          <TableCell><Skeleton className="h-6 w-32" /></TableCell>
                          <TableCell><Skeleton className="h-6 w-48" /></TableCell>
                          <TableCell><Skeleton className="h-6 w-20" /></TableCell>
                        </TableRow>
                      ))
                    ) : expenses && expenses.length > 0 ? (
                      expenses.map((expense) => (
                        <TableRow key={expense.id}>
                          <TableCell>{format(new Date(expense.date), 'MMM d, yyyy')}</TableCell>
                          <TableCell>{expense.category}</TableCell>
                          <TableCell>{expense.note || '-'}</TableCell>
                          <TableCell className="text-right font-medium">₱{expense.amount.toFixed(2)}</TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={4} className="text-center">
                          No expense data available for this period.
                        </TableCell>
                      </TableRow>
                    )}
                    {expenses && expenses.length > 0 && (
                      <TableRow className="font-bold">
                        <TableCell colSpan={3} className="text-right">Total</TableCell>
                        <TableCell className="text-right">₱{totalExpenses.toFixed(2)}</TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="loans" className="space-y-4">
          <div className="print-section">
            <div className="text-center mb-8 print-only">
              <h2 className="text-2xl font-bold">Loan Report</h2>
              <p className="text-muted-foreground">
                As of {format(new Date(), 'MMMM d, yyyy')}
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Total Active Loans</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {totalActiveLoans}
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Total Loan Amount</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    ₱{totalLoanAmount.toFixed(2)}
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Outstanding Balance</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    ₱{totalOutstandingLoans.toFixed(2)}
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <h3 className="text-xl font-bold mb-4">Active Loans</h3>
            <Card className="mb-8">
              <CardContent className="pt-6">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Member</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Start Date</TableHead>
                      <TableHead>Term</TableHead>
                      <TableHead className="text-right">Remaining Balance</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {isLoadingLoans ? (
                      Array.from({ length: 3 }).map((_, i) => (
                        <TableRow key={i}>
                          <TableCell><Skeleton className="h-6 w-32" /></TableCell>
                          <TableCell><Skeleton className="h-6 w-24" /></TableCell>
                          <TableCell><Skeleton className="h-6 w-24" /></TableCell>
                          <TableCell><Skeleton className="h-6 w-16" /></TableCell>
                          <TableCell><Skeleton className="h-6 w-24" /></TableCell>
                        </TableRow>
                      ))
                    ) : loansByStatus["active"]?.length > 0 ? (
                      loansByStatus["active"].map((loan) => (
                        <TableRow key={loan.id}>
                          <TableCell>{`Member #${loan.userId}`}</TableCell>
                          <TableCell>₱{loan.amount.toFixed(2)}</TableCell>
                          <TableCell>{new Date(loan.startDate).toLocaleDateString()}</TableCell>
                          <TableCell>{loan.term} months</TableCell>
                          <TableCell className="text-right font-medium">₱{loan.balance.toFixed(2)}</TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center">
                          No active loans found.
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
            
            <h3 className="text-xl font-bold mb-4">Loan Status Summary</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Active Loans</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {loansByStatus["active"]?.length || 0}
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Completed Loans</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {loansByStatus["completed"]?.length || 0}
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Pending Loans</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {loansByStatus["pending"]?.length || 0}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="members" className="space-y-4">
          <div className="print-section">
            <div className="text-center mb-8 print-only">
              <h2 className="text-2xl font-bold">Member Report</h2>
              <p className="text-muted-foreground">
                As of {format(new Date(), 'MMMM d, yyyy')}
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Total Members</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {totalMembers}
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Active Borrowers</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {new Set(loansByStatus["active"]?.map(loan => loan.userId) || []).size}
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Average Loan Amount</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    ₱{loans && loans.length > 0 ? (totalLoanAmount / loans.length).toFixed(2) : "0.00"}
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <h3 className="text-xl font-bold mb-4">Member List</h3>
            <Card>
              <CardContent className="pt-6">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>ID</TableHead>
                      <TableHead>Name</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Phone Number</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {isLoadingMembers ? (
                      Array.from({ length: 5 }).map((_, i) => (
                        <TableRow key={i}>
                          <TableCell><Skeleton className="h-6 w-12" /></TableCell>
                          <TableCell><Skeleton className="h-6 w-32" /></TableCell>
                          <TableCell><Skeleton className="h-6 w-48" /></TableCell>
                          <TableCell><Skeleton className="h-6 w-32" /></TableCell>
                          <TableCell><Skeleton className="h-6 w-20" /></TableCell>
                        </TableRow>
                      ))
                    ) : members && members.length > 0 ? (
                      members.map((member) => (
                        <TableRow key={member.id}>
                          <TableCell>{member.id}</TableCell>
                          <TableCell>{member.name}</TableCell>
                          <TableCell>{member.email}</TableCell>
                          <TableCell>{member.contactNumber || "N/A"}</TableCell>
                          <TableCell>{member.status || "Active"}</TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center">
                          No members found.
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
      
      <style>{`
        @media print {
          body * {
            visibility: hidden;
          }
          .print-section, .print-section * {
            visibility: visible;
          }
          .print-section {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
          }
          .print-only {
            display: block !important;
          }
          button, .no-print {
            display: none !important;
          }
        }
        .print-only {
          display: none;
        }
      `}</style>
    </AdminLayout>
  );
}
