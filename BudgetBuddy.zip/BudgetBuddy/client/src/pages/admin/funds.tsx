import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { 
  PiggyBank, Landmark, Wallet, ArrowUpDown, 
  Save, Loader2, RefreshCw, Calendar, ArrowUpRight, ArrowDownRight
} from "lucide-react";
import AdminLayout from "@/layouts/admin-layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Fund } from "@shared/schema";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Separator } from "@/components/ui/separator";

// Form schema for funds
const fundsSchema = z.object({
  onhandCash: z.coerce.number().min(0, "Amount cannot be negative"),
  capitalFund: z.coerce.number().min(0, "Amount cannot be negative"),
  reserveFund: z.coerce.number().min(0, "Amount cannot be negative"),
});

type FundsFormValues = z.infer<typeof fundsSchema>;

export default function AdminFunds() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isEditing, setIsEditing] = useState(false);
  
  // Fetch funds
  const { data: funds, isLoading } = useQuery<Fund>({
    queryKey: ["/api/admin/funds"],
  });

  // Fetch monthly income and expenses for this month
  const currentDate = new Date();
  const currentMonth = currentDate.getMonth() + 1;
  const currentYear = currentDate.getFullYear();
  
  const { data: monthlyIncome } = useQuery<{ amount: number }[]>({
    queryKey: [`/api/admin/income?year=${currentYear}&month=${currentMonth}`],
  });
  
  const { data: monthlyExpenses } = useQuery<{ amount: number }[]>({
    queryKey: [`/api/admin/expenses?year=${currentYear}&month=${currentMonth}`],
  });

  // Calculate monthly metrics
  const totalMonthlyIncome = monthlyIncome?.reduce((sum, item) => sum + item.amount, 0) || 0;
  const totalMonthlyExpenses = monthlyExpenses?.reduce((sum, item) => sum + item.amount, 0) || 0;
  const netMonthlyChange = totalMonthlyIncome - totalMonthlyExpenses;

  // Form for editing funds
  const form = useForm<FundsFormValues>({
    resolver: zodResolver(fundsSchema),
    defaultValues: {
      onhandCash: 0,
      capitalFund: 0,
      reserveFund: 0,
    },
  });

  // Update form values when funds data is loaded
  useState(() => {
    if (funds && !isLoading) {
      form.reset({
        onhandCash: funds.onhandCash,
        capitalFund: funds.capitalFund,
        reserveFund: funds.reserveFund,
      });
    }
  });

  // Update funds mutation
  const updateFundsMutation = useMutation({
    mutationFn: async (values: FundsFormValues) => {
      const res = await apiRequest("PUT", "/api/admin/funds", values);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/funds"] });
      
      toast({
        title: "Success",
        description: "Funds have been updated successfully.",
      });
      
      setIsEditing(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update funds.",
        variant: "destructive",
      });
    },
  });

  // Handle form submission
  const onSubmit = (values: FundsFormValues) => {
    updateFundsMutation.mutate(values);
  };

  // Calculate total funds
  const totalFunds = (funds?.onhandCash || 0) + (funds?.capitalFund || 0) + (funds?.reserveFund || 0);

  return (
    <AdminLayout>
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
        <h1 className="text-2xl font-bold">Cooperative Funds</h1>
        
        <div className="flex mt-4 sm:mt-0 gap-2">
          {isEditing ? (
            <Button onClick={() => setIsEditing(false)} variant="outline">
              Cancel Editing
            </Button>
          ) : (
            <Button onClick={() => setIsEditing(true)}>
              Edit Fund Values
            </Button>
          )}
          
          <Button
            variant="outline"
            size="icon"
            onClick={() => {
              queryClient.invalidateQueries({ queryKey: ["/api/admin/funds"] });
              queryClient.invalidateQueries({ queryKey: [`/api/admin/income?year=${currentYear}&month=${currentMonth}`] });
              queryClient.invalidateQueries({ queryKey: [`/api/admin/expenses?year=${currentYear}&month=${currentMonth}`] });
            }}
            disabled={isLoading}
          >
            <RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
          </Button>
        </div>
      </div>
      
      {/* Fund Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-6">
        <Card className="lg:col-span-4">
          <CardContent className="p-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
              <div>
                <h2 className="text-2xl font-bold">Total Available Funds</h2>
                <p className="text-muted-foreground">Combined capital and operational resources</p>
              </div>
              
              {isLoading ? (
                <Skeleton className="h-10 w-40" />
              ) : (
                <div className="text-3xl font-bold text-primary mt-2 sm:mt-0">
                  ₱{totalFunds.toLocaleString('en-PH', {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                  })}
                </div>
              )}
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardContent className="p-6">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-sm text-muted-foreground">On-Hand Cash</p>
                      {isLoading ? (
                        <Skeleton className="h-8 w-28 mt-1" />
                      ) : (
                        <h3 className="text-2xl font-bold mt-1">
                          ₱{funds?.onhandCash.toLocaleString('en-PH', {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2
                          }) || "0.00"}
                        </h3>
                      )}
                    </div>
                    <div className="p-2 bg-green-100 dark:bg-green-900/30 rounded-md">
                      <Wallet className="h-5 w-5 text-green-600 dark:text-green-400" />
                    </div>
                  </div>
                  <div className="mt-4 flex items-center text-sm">
                    <span className="text-green-500 flex items-center">
                      <ArrowUpRight className="mr-1 h-3 w-3" /> 
                      {netMonthlyChange > 0 ? "Increasing" : "Stable"}
                    </span>
                    <span className="text-gray-500 dark:text-gray-400 ml-2">this month</span>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-sm text-muted-foreground">Capital Fund</p>
                      {isLoading ? (
                        <Skeleton className="h-8 w-28 mt-1" />
                      ) : (
                        <h3 className="text-2xl font-bold mt-1">
                          ₱{funds?.capitalFund.toLocaleString('en-PH', {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2
                          }) || "0.00"}
                        </h3>
                      )}
                    </div>
                    <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded-md">
                      <Landmark className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                    </div>
                  </div>
                  <div className="mt-4 flex items-center text-sm">
                    <span className="text-blue-500 flex items-center">
                      <ArrowUpRight className="mr-1 h-3 w-3" /> Long term
                    </span>
                    <span className="text-gray-500 dark:text-gray-400 ml-2">investment</span>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-sm text-muted-foreground">Reserve Fund</p>
                      {isLoading ? (
                        <Skeleton className="h-8 w-28 mt-1" />
                      ) : (
                        <h3 className="text-2xl font-bold mt-1">
                          ₱{funds?.reserveFund.toLocaleString('en-PH', {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2
                          }) || "0.00"}
                        </h3>
                      )}
                    </div>
                    <div className="p-2 bg-purple-100 dark:bg-purple-900/30 rounded-md">
                      <PiggyBank className="h-5 w-5 text-purple-600 dark:text-purple-400" />
                    </div>
                  </div>
                  <div className="mt-4 flex items-center text-sm">
                    <span className="text-purple-500 flex items-center">
                      <ArrowUpRight className="mr-1 h-3 w-3" /> Emergency
                    </span>
                    <span className="text-gray-500 dark:text-gray-400 ml-2">fund for contingencies</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Fund Management and Monthly Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Fund Management Form */}
        <Card>
          <CardHeader>
            <CardTitle>Fund Management</CardTitle>
            <CardDescription>Update and manage cooperative fund allocations</CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-4">
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-10 w-full" />
              </div>
            ) : (
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="onhandCash"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>On-Hand Cash (₱)</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            step="0.01"
                            {...field}
                            disabled={!isEditing}
                            className={!isEditing ? "opacity-60" : ""}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="capitalFund"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Capital Fund (₱)</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            step="0.01"
                            {...field}
                            disabled={!isEditing}
                            className={!isEditing ? "opacity-60" : ""}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="reserveFund"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Reserve Fund (₱)</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            step="0.01"
                            {...field}
                            disabled={!isEditing}
                            className={!isEditing ? "opacity-60" : ""}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  {isEditing && (
                    <div className="pt-4">
                      <Button
                        type="submit"
                        className="w-full"
                        disabled={updateFundsMutation.isPending}
                      >
                        {updateFundsMutation.isPending ? (
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        ) : (
                          <Save className="mr-2 h-4 w-4" />
                        )}
                        Save Fund Changes
                      </Button>
                    </div>
                  )}
                </form>
              </Form>
            )}
          </CardContent>
        </Card>
        
        {/* Monthly Financial Summary */}
        <Card>
          <CardHeader>
            <CardTitle>Monthly Financial Summary</CardTitle>
            <CardDescription>Overview of this month's income and expenses</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <Calendar className="h-5 w-5 mr-2 text-muted-foreground" />
                  <h3 className="text-lg font-medium">
                    {new Date().toLocaleString('default', { month: 'long', year: 'numeric' })}
                  </h3>
                </div>
                <Button variant="outline" size="sm" asChild>
                  <a href="/admin/income-expenses">View Details</a>
                </Button>
              </div>
              
              <Separator />
              
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-gray-100 dark:bg-gray-800 rounded-lg">
                  <div className="flex justify-between items-center mb-2">
                    <h4 className="font-medium">Income</h4>
                    <ArrowUpRight className="h-4 w-4 text-green-500" />
                  </div>
                  <p className="text-2xl font-bold text-green-600 dark:text-green-400">
                    ₱{totalMonthlyIncome.toLocaleString('en-PH', {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2
                    })}
                  </p>
                </div>
                
                <div className="p-4 bg-gray-100 dark:bg-gray-800 rounded-lg">
                  <div className="flex justify-between items-center mb-2">
                    <h4 className="font-medium">Expenses</h4>
                    <ArrowDownRight className="h-4 w-4 text-red-500" />
                  </div>
                  <p className="text-2xl font-bold text-red-600 dark:text-red-400">
                    ₱{totalMonthlyExpenses.toLocaleString('en-PH', {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2
                    })}
                  </p>
                </div>
              </div>
              
              <Separator />
              
              <div className="pt-2">
                <div className="flex justify-between items-center mb-2">
                  <h4 className="font-medium">Net Change</h4>
                  {netMonthlyChange >= 0 ? (
                    <span className="text-green-500 flex items-center">
                      <ArrowUpRight className="mr-1 h-4 w-4" /> Positive
                    </span>
                  ) : (
                    <span className="text-red-500 flex items-center">
                      <ArrowDownRight className="mr-1 h-4 w-4" /> Negative
                    </span>
                  )}
                </div>
                <p className={`text-2xl font-bold ${
                  netMonthlyChange >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'
                }`}>
                  ₱{Math.abs(netMonthlyChange).toLocaleString('en-PH', {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                  })}
                </p>
              </div>
              
              <div className="pt-4">
                <div className="h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                  {totalMonthlyIncome > 0 && (
                    <div 
                      className="h-full bg-green-500" 
                      style={{ 
                        width: `${Math.min(100, (totalMonthlyIncome / (totalMonthlyIncome + totalMonthlyExpenses)) * 100)}%` 
                      }}
                    ></div>
                  )}
                </div>
                <div className="flex justify-between mt-2 text-xs text-muted-foreground">
                  <span>Income: {Math.round((totalMonthlyIncome / (totalMonthlyIncome + totalMonthlyExpenses || 1)) * 100)}%</span>
                  <span>Expenses: {Math.round((totalMonthlyExpenses / (totalMonthlyIncome + totalMonthlyExpenses || 1)) * 100)}%</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}
