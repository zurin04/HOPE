import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import MemberLayout from "@/layouts/member-layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Search, Newspaper, Calendar, RefreshCw, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { NewsFeed } from "@shared/schema";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";

export default function MemberNews() {
  const [searchTerm, setSearchTerm] = useState("");
  const queryClient = useQueryClient();
  
  // Fetch all news
  const { data: news, isLoading } = useQuery<NewsFeed[]>({
    queryKey: ["/api/news"],
  });

  // Filter news based on search
  const filteredNews = news?.filter(item => 
    item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.content.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <MemberLayout>
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
        <h1 className="text-2xl font-bold">Cooperative News</h1>
        
        <div className="relative w-full sm:w-64 mt-4 sm:mt-0">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            className="pl-8 w-full"
            placeholder="Search news..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          {searchTerm && (
            <button
              onClick={() => setSearchTerm("")}
              className="absolute right-2.5 top-2.5 text-muted-foreground hover:text-foreground"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>
      </div>
      
      {/* Placeholder when loading */}
      {isLoading && (
        <div className="space-y-6">
          <Skeleton className="h-40 w-full" />
          <Skeleton className="h-40 w-full" />
          <Skeleton className="h-40 w-full" />
        </div>
      )}
      
      {/* No news found state */}
      {!isLoading && (!filteredNews || filteredNews.length === 0) && (
        <div className="text-center py-16">
          <Newspaper className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
          <h2 className="text-xl font-semibold mb-2">No News Available</h2>
          <p className="text-muted-foreground mb-6">
            {searchTerm 
              ? "No news found matching your search criteria." 
              : "There are no news or announcements at the moment."}
          </p>
          {searchTerm && (
            <Button onClick={() => setSearchTerm("")}>
              Clear Search
            </Button>
          )}
        </div>
      )}
      
      {/* News Feed */}
      {!isLoading && filteredNews && filteredNews.length > 0 && (
        <div className="space-y-6">
          {filteredNews.map((item) => (
            <Card key={item.id} className="overflow-hidden">
              <CardHeader className="pb-3">
                <CardTitle className="text-xl">{item.title}</CardTitle>
                <div className="flex items-center text-muted-foreground text-sm">
                  <Calendar className="h-4 w-4 mr-1" />
                  <span>Posted on {format(new Date(item.createdAt), "MMMM d, yyyy")}</span>
                </div>
              </CardHeader>
              <CardContent>
                <div className="prose dark:prose-invert max-w-none">
                  <p>
                    {item.content.split('\n').map((paragraph, i) => (
                      <span key={i}>
                        {paragraph}
                        <br />
                      </span>
                    ))}
                  </p>
                </div>
              </CardContent>
            </Card>
          ))}
          
          {/* Refresh button */}
          <div className="flex justify-center pt-4">
            <Button 
              variant="outline" 
              className="flex items-center"
              onClick={() => queryClient.invalidateQueries({ queryKey: ["/api/news"] })}
            >
              <RefreshCw className="mr-2 h-4 w-4" />
              Refresh News Feed
            </Button>
          </div>
        </div>
      )}
    </MemberLayout>
  );
}
