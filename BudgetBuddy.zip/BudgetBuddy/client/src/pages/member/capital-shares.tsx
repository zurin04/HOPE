import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { format } from "date-fns";
import { ArrowUpIcon, DownloadIcon, DollarSign, LineChart, Loader2 } from "lucide-react";
import MemberLayout from "@/layouts/member-layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { CapitalShare } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";
import { apiRequest, queryClient } from "@/lib/queryClient";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export default function MemberCapitalShares() {
  const [showLoanDialog, setShowLoanDialog] = useState(false);
  const [loanAmount, setLoanAmount] = useState(0);
  const [loanTerm, setLoanTerm] = useState("12");
  const [loanSchedule, setLoanSchedule] = useState("monthly");
  const { toast } = useToast();

  // Fetch capital share data
  const { data: capitalShare, isLoading } = useQuery<CapitalShare>({
    queryKey: ["/api/members/capital-shares"],
  });

  const maxLoanAmount = capitalShare ? capitalShare.amount * 0.8 : 0;

  // Create loan mutation
  const createLoanMutation = useMutation({
    mutationFn: async (loanData: any) => {
      const res = await apiRequest("POST", "/api/members/loans", loanData);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Loan Application Successful",
        description: "Your loan application has been submitted successfully.",
      });
      setShowLoanDialog(false);
      // Refresh loan data
      queryClient.invalidateQueries({ queryKey: ["/api/members/loans"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Loan Application Failed",
        description: error.message || "Failed to submit loan application.",
        variant: "destructive",
      });
    },
  });

  const handleLoanSubmit = () => {
    if (loanAmount <= 0) {
      toast({
        title: "Invalid Loan Amount",
        description: "Please enter a valid loan amount greater than zero.",
        variant: "destructive",
      });
      return;
    }

    if (loanAmount > maxLoanAmount) {
      toast({
        title: "Loan Amount Exceeds Limit",
        description: `You can only borrow up to 80% of your capital share (₱${maxLoanAmount.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })})`,
        variant: "destructive",
      });
      return;
    }

    createLoanMutation.mutate({
      amount: loanAmount,
      term: parseInt(loanTerm),
      schedule: loanSchedule,
      interest: 5, // 5% interest rate
    });
  };

  // Mock data for capital growth chart
  // In a real app, you would fetch this from an API
  const capitalHistory = [
    { date: new Date(2023, 0, 1), amount: capitalShare?.amount ? capitalShare.amount * 0.5 : 0 },
    { date: new Date(2023, 3, 1), amount: capitalShare?.amount ? capitalShare.amount * 0.6 : 0 },
    { date: new Date(2023, 6, 1), amount: capitalShare?.amount ? capitalShare.amount * 0.8 : 0 },
    { date: new Date(2023, 9, 1), amount: capitalShare?.amount ? capitalShare.amount * 0.9 : 0 },
    { date: new Date(), amount: capitalShare?.amount || 0 },
  ];

  return (
    <MemberLayout>
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
        <h1 className="text-2xl font-bold">My Capital Shares</h1>
        <div className="mt-4 sm:mt-0">
          <button
            className="bg-primary text-white px-4 py-2 rounded-md flex items-center justify-center hover:bg-primary/90 transition-colors"
            onClick={() => setShowLoanDialog(true)}
          >
            <DollarSign className="h-4 w-4 mr-2" />
            Apply for CBU Loan
          </button>
        </div>
      </div>
      
      {/* Capital Share Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle>Capital Share Summary</CardTitle>
            <CardDescription>Current capital share details</CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-4">
                <Skeleton className="h-16 w-full" />
                <Skeleton className="h-20 w-full" />
              </div>
            ) : (
              <>
                <div className="flex items-center p-4 bg-gray-100 dark:bg-gray-800 rounded-lg">
                  <div className="mr-4 rounded-full bg-primary/20 p-3">
                    <DollarSign className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Total Capital Share</p>
                    <p className="text-2xl font-bold">
                      ₱{capitalShare?.amount.toLocaleString('en-PH', {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                      }) || "0.00"}
                    </p>
                  </div>
                </div>
                
                <div className="mt-4 space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500 dark:text-gray-400">Last Updated</span>
                    <span className="font-medium">
                      {capitalShare?.updatedAt 
                        ? format(new Date(capitalShare.updatedAt), "MMMM d, yyyy") 
                        : "N/A"}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500 dark:text-gray-400">Annual Growth</span>
                    <span className="font-medium text-green-600 dark:text-green-400 flex items-center">
                      <ArrowUpIcon className="mr-1 h-3 w-3" /> 12%
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500 dark:text-gray-400">Member Since</span>
                    <span className="font-medium">
                      {capitalShare?.updatedAt 
                        ? format(new Date(capitalShare.updatedAt), "yyyy") 
                        : "N/A"}
                    </span>
                  </div>
                </div>
              </>
            )}
          </CardContent>
        </Card>
        
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Capital Growth</CardTitle>
            <CardDescription>Capital share growth over time</CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-64 w-full" />
            ) : (
              <div className="flex h-64 items-center justify-center">
                <div className="text-center">
                  <LineChart className="h-16 w-16 text-gray-400 dark:text-gray-500 mb-4" />
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    Capital share growth chart will be displayed here.
                  </p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
      
      {/* Capital Share Transactions */}
      <Card>
        <CardHeader>
          <div className="flex justify-between">
            <div>
              <CardTitle>Capital Share Transactions</CardTitle>
              <CardDescription>History of all capital share deposits and withdrawals</CardDescription>
            </div>
            <div className="flex items-center space-x-2">
              <button className="text-sm flex items-center text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200">
                <DownloadIcon className="h-4 w-4 mr-1" />
                Export CSV
              </button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4">
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Transaction Type</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Balance After</TableHead>
                    <TableHead>Description</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {capitalHistory.length > 0 ? (
                    capitalHistory.map((item, index) => (
                      <TableRow key={index}>
                        <TableCell>{format(item.date, "MMM d, yyyy")}</TableCell>
                        <TableCell>
                          <span className="px-2 py-1 rounded-full text-xs bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                            Deposit
                          </span>
                        </TableCell>
                        <TableCell>₱{item.amount.toLocaleString('en-PH', {
                          minimumFractionDigits: 2,
                          maximumFractionDigits: 2
                        })}</TableCell>
                        <TableCell>₱{item.amount.toLocaleString('en-PH', {
                          minimumFractionDigits: 2,
                          maximumFractionDigits: 2
                        })}</TableCell>
                        <TableCell>
                          {index === 0 ? "Initial deposit" : index === capitalHistory.length - 1 ? "Latest update" : "Capital contribution"}
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={5} className="text-center py-8 text-gray-500 dark:text-gray-400">
                        No capital share transactions available.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
      
      {/* CBU Loan Dialog */}
      <Dialog open={showLoanDialog} onOpenChange={setShowLoanDialog}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Apply for CBU Loan</DialogTitle>
            <DialogDescription>
              You can borrow up to 80% of your capital share. Current max: ₱{maxLoanAmount.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="loan-amount">Loan Amount</Label>
              <div className="flex items-center">
                <span className="bg-gray-100 dark:bg-gray-800 px-3 py-2 border border-r-0 rounded-l-md border-gray-300 dark:border-gray-600">₱</span>
                <Input
                  id="loan-amount"
                  type="number"
                  min="0"
                  max={maxLoanAmount}
                  value={loanAmount}
                  onChange={(e) => setLoanAmount(parseFloat(e.target.value) || 0)}
                  className="rounded-l-none"
                />
              </div>
              <div className="pt-2">
                <Label>Percentage of maximum ({(loanAmount / maxLoanAmount * 100).toFixed(0)}%)</Label>
                <Slider
                  min={0}
                  max={maxLoanAmount}
                  step={1000}
                  value={[loanAmount]}
                  onValueChange={(value) => setLoanAmount(value[0])}
                  className="mt-2"
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="loan-term">Term Length (months)</Label>
              <Select value={loanTerm} onValueChange={setLoanTerm}>
                <SelectTrigger id="loan-term">
                  <SelectValue placeholder="Select term length" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="3">3 months</SelectItem>
                  <SelectItem value="6">6 months</SelectItem>
                  <SelectItem value="12">12 months</SelectItem>
                  <SelectItem value="24">24 months</SelectItem>
                  <SelectItem value="36">36 months</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="payment-schedule">Payment Schedule</Label>
              <Select value={loanSchedule} onValueChange={setLoanSchedule}>
                <SelectTrigger id="payment-schedule">
                  <SelectValue placeholder="Select payment schedule" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="weekly">Weekly</SelectItem>
                  <SelectItem value="monthly">Monthly</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-md mt-2">
              <h4 className="font-medium mb-2">Loan Summary</h4>
              <div className="space-y-1 text-sm">
                <div className="flex justify-between">
                  <span>Loan Amount:</span>
                  <span className="font-medium">₱{loanAmount.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                </div>
                <div className="flex justify-between">
                  <span>Interest Rate:</span>
                  <span className="font-medium">5%</span>
                </div>
                <div className="flex justify-between">
                  <span>Term Length:</span>
                  <span className="font-medium">{loanTerm} months</span>
                </div>
                <div className="flex justify-between">
                  <span>Payment Schedule:</span>
                  <span className="font-medium capitalize">{loanSchedule}</span>
                </div>
                <div className="flex justify-between border-t border-gray-200 dark:border-gray-700 pt-1 mt-1">
                  <span>Estimated Payment:</span>
                  <span className="font-medium">
                    ₱{(loanAmount * (1 + 0.05) / parseInt(loanTerm)).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    /{loanSchedule === 'weekly' ? 'week' : 'month'}
                  </span>
                </div>
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowLoanDialog(false)}>Cancel</Button>
            <Button 
              onClick={handleLoanSubmit} 
              disabled={loanAmount <= 0 || loanAmount > maxLoanAmount || createLoanMutation.isPending}
            >
              {createLoanMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Processing...
                </>
              ) : (
                'Apply for Loan'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </MemberLayout>
  );
}
