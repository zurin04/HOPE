import * as XLSX from 'xlsx';

export interface ExportOptions {
  filename: string;
  sheetName?: string;
  columns?: { key: string; header: string }[];
}

export const exportToExcel = <T extends Record<string, any>>(
  data: T[],
  options: ExportOptions
) => {
  const { filename, sheetName = 'Sheet1', columns } = options;

  // If columns are provided, map data to include only specified columns
  const mappedData = columns
    ? data.map((item) =>
        columns.reduce(
          (acc, col) => ({
            ...acc,
            [col.header]: item[col.key],
          }),
          {}
        )
      )
    : data;

  // Create a worksheet
  const worksheet = XLSX.utils.json_to_sheet(mappedData);
  
  // Apply column headers
  if (columns) {
    // Set header row
    XLSX.utils.sheet_add_aoa(
      worksheet, 
      [columns.map(col => col.header)], 
      { origin: 'A1' }
    );
  }

  // Create a workbook
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, sheetName);

  // Generate Excel file
  XLSX.writeFile(workbook, `${filename}.xlsx`);
};

// Export multiple sheets in one file
export const exportMultipleSheets = <T extends Record<string, any>>(
  sheets: {
    data: T[];
    sheetName: string;
    columns?: { key: string; header: string }[];
  }[],
  filename: string
) => {
  const workbook = XLSX.utils.book_new();

  sheets.forEach((sheet) => {
    const { data, sheetName, columns } = sheet;

    // Map data if columns specified
    const mappedData = columns
      ? data.map((item) =>
          columns.reduce(
            (acc, col) => ({
              ...acc,
              [col.header]: item[col.key],
            }),
            {}
          )
        )
      : data;

    // Create worksheet
    const worksheet = XLSX.utils.json_to_sheet(mappedData);
    
    // Apply column headers
    if (columns) {
      XLSX.utils.sheet_add_aoa(
        worksheet, 
        [columns.map(col => col.header)], 
        { origin: 'A1' }
      );
    }

    // Add worksheet to workbook
    XLSX.utils.book_append_sheet(workbook, worksheet, sheetName);
  });

  // Generate Excel file
  XLSX.writeFile(workbook, `${filename}.xlsx`);
};
